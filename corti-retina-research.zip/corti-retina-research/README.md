# CortiRetina — Retinal Vascular Biomarkers for Cortisol-Related & Systemic Vascular Risk

Research pipeline extracting quantitative vessel biomarkers (caliber, tortuosity,
fractal dimension, AVR-proxy) from retinal fundus images via Frangi vesselness
filtering, and testing them against real downstream targets: diabetic retinopathy
(DR) grade and carotid intima-media thickness (CIMT).

## Status (honest, as of this commit)

**Working and validated:**
- Frangi-filter-based vessel feature extraction pipeline (`src/run_local_pipeline.py`,
  `src/run_cimt_pipeline.py`) — runs end-to-end on EyePACS, Messidor-2, and the
  [China-Fundus-CIMT dataset](https://www.nature.com/articles/s41597-025-04930-z)
- Preliminary sanity-check model: vessel biomarkers → DR grade (RandomForest,
  stratified 300-image sample). Current accuracy is modest (~25-32%, barely above
  the 20% chance baseline for 5-class balanced data) — this reflects a small sample
  and a feature set that likely needs expansion, not a validated result yet.
- CIMT thickened-vs-normal classification pipeline built and ready to run once the
  dataset's JSON metadata keys are inspected/confirmed (see `INSPECT_ONLY` flag in
  `run_cimt_pipeline.py`).

**Hypothesis-stage, not yet trained on real data:**
- `cortisol_vascular_pathology_mapper.py` and `frangi_to_cortisol_integration.py`
  encode a clinically-motivated *rule-based* mapping from DR-like lesion patterns
  to hypothesized cortisol status and CVD risk score. This is a structured
  hypothesis translating known DR lesion biology to cortisol-driven endothelial
  dysfunction — it has **not been trained or validated against real cortisol-labeled
  patient data**, since no such public dataset currently exists. This is the core
  gap this project is trying to close.

## Why this approach

Standard CVD risk calculators (Framingham, ASCVD/PCE) use age, cholesterol, blood
pressure, and smoking status — they don't account for cortisol-driven vascular
damage, which can occur independent of diabetes. Retinal fundus imaging is a
non-invasive proxy for systemic vascular health, and DR's well-characterized lesion
taxonomy offers a template for quantifying vascular damage patterns from a different
underlying cause (hypercortisolism vs. hyperglycemia).

## Repo layout

```
src/
  run_local_pipeline.py              # EyePACS + Messidor-2 → vessel features → DR-grade model
  run_cimt_pipeline.py                # China-Fundus-CIMT → vessel features → CIMT thickened/normal model
  download_and_extract_retinal_data.py
  cortisol_vascular_pathology_mapper.py   # hypothesis-stage: DR lesion → cortisol mapping
  frangi_to_cortisol_integration.py       # hypothesis-stage: full risk-scoring pipeline
  vessel_calibration_agent_framework.py   # multi-agent calibration (pressure/motion/flicker)
docs/
  frangi_filter_feature_extraction.md
  kaggle_dataset_extraction_guide.md
  COMPLETE_PIPELINE_GUIDE.md
outputs/                              # generated CSVs, models, reports land here (gitignored)
```

## Setup

```bash
pip install -r requirements.txt
```

Data is not included in this repo (see `.gitignore`) — each dataset has its own
license/redistribution terms. Get it yourself via Kaggle API:

```bash
kaggle datasets download -d sovitrath/diabetic-retinopathy-2015-data-colored-resized -p ./data/eyepacs --unzip
kaggle datasets download -d google-brain/messidor2-dr-grades -p ./data/messidor2 --unzip
```

China-Fundus-CIMT is distributed via Figshare — see the
[Scientific Data paper](https://www.nature.com/articles/s41597-025-04930-z) for
access instructions.

## Running

```bash
python src/run_local_pipeline.py     # DR-grade sanity check on EyePACS/Messidor-2
python src/run_cimt_pipeline.py      # CIMT thickened/normal model (real clinical outcome)
```

Edit the path variables at the top of each script to match your local data location.

## Next steps

- [ ] Scale EyePACS sample size beyond 300 images per class to properly power the
      minority DR grades
- [ ] Run the CIMT pipeline as the primary validation target — it's a real,
      established CVD surrogate marker, unlike DR grade
- [ ] Acquire real cortisol-labeled retinal imaging cohort (metyrapone-treated /
      Cushing's patients) to actually train the cortisol-mapping layer, rather than
      relying on the current rule-based DR analogy
- [ ] Cross-validate feature extraction against manual vessel annotations

## Author

Ramsha Zuberi — Clinical AI Researcher, LN Technology / Aga Khan University
ORCID: 0009-0004-9272-0343
