#!/usr/bin/env python3
"""
Local Retinal Vessel Pipeline v2 — structural vascular biomarkers
(caliber, AVR-proxy, tortuosity, fractal dimension) instead of the
generic DR-grade-proxy features from v1.

WHY THIS CHANGED FROM v1
-------------------------
v1 extracted generic vessel blob features (area/density/contour count)
and validated them against DR grade. That's a mismatch for a
hypercortisolism/endothelial-function hypothesis: DR grading leans on
hemorrhages, exudates and microaneurysms, not vessel caliber or
tortuosity, so weak DR classification accuracy in v1 didn't actually
tell you whether the vessel-measurement code was any good.

This version extracts the biomarkers that literature on hypertensive/
diabetic retinal vascular remodeling — and your own proposal — actually
cares about:
  - vessel caliber (via distance-transform radius along the skeleton)
  - an AVR-style ratio between two color-separated vessel populations
  - tortuosity (arc length / chord length) per vessel segment
  - fractal dimension (structural complexity of the vascular tree)

WHAT THIS STILL CANNOT DO
--------------------------
- No flicker-light dynamic dilation / NO-dependent vasodilation. EyePACS
  and Messidor-2 are single static photos, not DVA video sequences. That
  part of your hypothesis can only be tested on real patient DVA data.
- No true clinical AVR. Clinical AVR (Knudtson/Parr-Hubbard formulas)
  measures the 6 largest arterioles/venules in a defined zone around the
  optic disc, using a trained artery/vein classifier. This script uses a
  much cruder brightness/color heuristic to split "vessel population A"
  vs "vessel population B" — it is a rough structural proxy, not a
  validated AVR measurement. Label it as such in any writeup.
- No age-normalized "vascular age" score. Neither the public EyePACS
  Kaggle release nor the standard Messidor-2 label file publishes patient
  age, so that regression can't be built on these two datasets. (Earlier
  guidance in this conversation claimed both had age metadata — that was
  wrong; correcting it here.)

Dependencies beyond v1: pip install skan --break-system-packages
(skan is used for per-branch arc-length / chord-length / mean-caliber
via skeleton graph analysis — much more robust than hand-rolled
skeleton-segment splitting.)

EDIT THESE FOR YOUR MACHINE:
"""
EYEPACS_DIR   = "./data/eyepacs"          # contains folders 0/, 1/, 2/, 3/, 4/ (folder name = DR grade)
MESSIDOR_DIR  = "./data/messidor2"        # contains messidor_data.csv + image files somewhere inside
SAMPLE_SIZE   = 300                       # None = process everything (slow); start small to test
OUTPUT_DIR    = "./outputs"
MIN_SEGMENT_LENGTH_PX = 8                 # skeleton branches shorter than this are treated as noise, not real vessel segments

import os
import warnings
from pathlib import Path
from collections import Counter

import cv2
import numpy as np
import pandas as pd
from tqdm import tqdm

warnings.filterwarnings("ignore")

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp")


# ----------------------------------------------------------------------------
# Vascular biomarker extraction
# ----------------------------------------------------------------------------
def extract_vascular_features(image_path):
    """
    Returns a dict of structural vascular biomarkers, or None if the image
    couldn't be read or no usable vessel segments were found.
    """
    from skimage.filters import frangi
    from skimage.morphology import skeletonize, remove_small_objects
    from scipy.ndimage import distance_transform_edt
    from skan import Skeleton, summarize
    from sklearn.cluster import KMeans

    img_bgr = cv2.imread(str(image_path))
    if img_bgr is None:
        return None
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

    # Green channel has the strongest vessel/background contrast in color
    # fundus photos — standard preprocessing choice in retinal vessel work.
    green = img_rgb[:, :, 1]
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(green)

    vesselness = frangi(enhanced, sigmas=range(1, 6), alpha=0.5, beta=0.5)
    thresh = np.percentile(vesselness, 95)
    vessel_mask = vesselness > thresh
    vessel_mask = remove_small_objects(vessel_mask, min_size=15)

    h, w = green.shape
    vessel_density = float(vessel_mask.sum()) / (h * w)

    if vessel_mask.sum() < 50:
        # Not enough vessel pixels to say anything meaningful — likely a
        # poor-quality / out-of-focus image (EyePACS is known to contain some).
        return {
            "vessel_density": vessel_density,
            "segment_count": 0,
            "mean_caliber_px": np.nan,
            "caliber_std_px": np.nan,
            "avr_proxy": np.nan,
            "population_a_caliber_px": np.nan,
            "population_b_caliber_px": np.nan,
            "mean_tortuosity": np.nan,
            "tortuosity_std": np.nan,
            "high_tortuosity_fraction": np.nan,
            "fractal_dimension": np.nan,
        }

    # --- Caliber + tortuosity via skeleton graph analysis ---
    skel = skeletonize(vessel_mask)
    radius_map = distance_transform_edt(vessel_mask)
    # Weight skeleton pixels by local vessel radius so skan's per-branch
    # "mean-pixel-value" gives us mean caliber (radius) along that segment.
    skel_weighted = np.where(skel, radius_map, 0.0)

    segment_count = 0
    calibers, tortuosities = [], []
    branch_colors = []  # for AV-proxy color clustering
    try:
        sk = Skeleton(skel_weighted)
        branches = summarize(sk, separator="-")
        branches = branches[branches["branch-distance"] >= MIN_SEGMENT_LENGTH_PX]

        for _, b in branches.iterrows():
            arc = b["branch-distance"]
            chord = max(b["euclidean-distance"], 1.0)  # guard div-by-zero
            tortuosity = arc / chord
            caliber_px = 2.0 * b["mean-pixel-value"]  # diameter = 2 * radius

            calibers.append(caliber_px)
            tortuosities.append(tortuosity)

            ry = int((b["image-coord-src-0"] + b["image-coord-dst-0"]) / 2)
            rx = int((b["image-coord-src-1"] + b["image-coord-dst-1"]) / 2)
            ry, rx = np.clip(ry, 0, h - 1), np.clip(rx, 0, w - 1)
            r, g, bch = img_rgb[ry, rx].astype(float)
            # Heuristic color feature only: arteries tend to read brighter/
            # redder, veins darker/more blue-purple in color fundus photos.
            # This is NOT a validated AV classifier — see module docstring.
            branch_colors.append(r / (r + g + bch + 1e-6))

        segment_count = len(calibers)
    except Exception:
        segment_count = 0

    if segment_count >= 4:
        calibers_arr = np.array(calibers)
        tort_arr = np.array(tortuosities)
        colors_arr = np.array(branch_colors).reshape(-1, 1)

        mean_caliber = float(calibers_arr.mean())
        caliber_std = float(calibers_arr.std())
        mean_tort = float(tort_arr.mean())
        tort_std = float(tort_arr.std())
        high_tort_frac = float((tort_arr > 1.10).mean())

        # Split vessel segments into two color-based populations as a rough
        # structural proxy for "artery-like" vs "vein-like" caliber ratio.
        km = KMeans(n_clusters=2, n_init=5, random_state=42).fit(colors_arr)
        labels = km.labels_
        pop_a_caliber = float(calibers_arr[labels == 0].mean()) if (labels == 0).any() else np.nan
        pop_b_caliber = float(calibers_arr[labels == 1].mean()) if (labels == 1).any() else np.nan
        # Always express as brighter-population / darker-population so the
        # ratio direction is consistent across images.
        if km.cluster_centers_[0, 0] >= km.cluster_centers_[1, 0]:
            avr_proxy = pop_a_caliber / pop_b_caliber if pop_b_caliber else np.nan
        else:
            avr_proxy = pop_b_caliber / pop_a_caliber if pop_a_caliber else np.nan
    else:
        mean_caliber = caliber_std = mean_tort = tort_std = np.nan
        high_tort_frac = avr_proxy = pop_a_caliber = pop_b_caliber = np.nan

    # --- Fractal dimension via box counting (structural complexity) ---
    fractal_dimension = _box_count_fractal_dim(vessel_mask)

    return {
        "vessel_density": vessel_density,
        "segment_count": segment_count,
        "mean_caliber_px": mean_caliber,
        "caliber_std_px": caliber_std,
        "avr_proxy": avr_proxy,
        "population_a_caliber_px": pop_a_caliber,
        "population_b_caliber_px": pop_b_caliber,
        "mean_tortuosity": mean_tort,
        "tortuosity_std": tort_std,
        "high_tortuosity_fraction": high_tort_frac,
        "fractal_dimension": fractal_dimension,
    }


def _box_count_fractal_dim(binary_mask, min_box=4, max_box=64):
    """Standard box-counting estimate of fractal dimension of a binary mask."""
    sizes = []
    counts = []
    box_size = min_box
    h, w = binary_mask.shape
    while box_size <= max_box:
        n_y = h // box_size
        n_x = w // box_size
        if n_y == 0 or n_x == 0:
            break
        cropped = binary_mask[: n_y * box_size, : n_x * box_size]
        reshaped = cropped.reshape(n_y, box_size, n_x, box_size)
        occupied = reshaped.any(axis=(1, 3))
        count = occupied.sum()
        if count > 0:
            sizes.append(box_size)
            counts.append(count)
        box_size *= 2

    if len(sizes) < 2:
        return np.nan
    log_sizes = np.log(1.0 / np.array(sizes, dtype=float))
    log_counts = np.log(np.array(counts, dtype=float))
    slope, _ = np.polyfit(log_sizes, log_counts, 1)
    return float(slope)


# ----------------------------------------------------------------------------
# Dataset loaders
# ----------------------------------------------------------------------------
def process_eyepacs(eyepacs_dir, sample_size=None):
    base = Path(eyepacs_dir)
    grade_folders = [f for f in base.iterdir() if f.is_dir() and f.name.isdigit()]

    if not grade_folders:
        print(f"  ⚠ No numbered class folders (0-4) found in {eyepacs_dir}, skipping EyePACS")
        return pd.DataFrame()

    all_images = []
    for folder in grade_folders:
        grade = int(folder.name)
        for img_path in folder.iterdir():
            if img_path.suffix.lower() in IMAGE_EXTENSIONS:
                all_images.append((img_path, grade))

    print(f"  Found {len(all_images)} total images across grades {sorted(int(f.name) for f in grade_folders)}")

    full_dist = Counter(g for _, g in all_images)
    print("  Full EyePACS grade distribution (before sampling):")
    for grade in sorted(full_dist):
        count = full_dist[grade]
        pct = 100 * count / len(all_images)
        print(f"    Grade {grade}: {count:6d} ({pct:5.1f}%)")

    if sample_size:
        import random
        random.seed(42)
        by_grade = {}
        for img_path, grade in all_images:
            by_grade.setdefault(grade, []).append(img_path)

        n_grades = len(by_grade)
        per_grade_target = max(sample_size // n_grades, 1)

        sampled = []
        for grade, paths in by_grade.items():
            random.shuffle(paths)
            take = min(per_grade_target, len(paths))
            sampled.extend((p, grade) for p in paths[:take])

        random.shuffle(sampled)
        all_images = sampled
        print(f"  Stratified sample: {len(all_images)} images "
              f"(~{per_grade_target} per grade, capped by availability)")

    rows = []
    for img_path, grade in tqdm(all_images, desc="EyePACS"):
        feats = extract_vascular_features(img_path)
        if feats:
            feats.update(dataset="EyePACS", image_id=img_path.stem, dr_grade=grade)
            rows.append(feats)
    return pd.DataFrame(rows)


def process_messidor(messidor_dir, sample_size=None):
    """
    Uses messidor_data.csv with columns: image_id, adjudicated_dr_grade,
    adjudicated_dme, adjudicated_gradable.

    FIX vs v1: the old indexer only globbed lowercase *.png/*.jpg/*.jpeg,
    which returned 0 files (Messidor-2 images are commonly .tif/.TIF, or
    just differently-cased). This version globs case-insensitively across
    a wider extension set, and — critically — prints a diagnostic listing
    of what extensions actually exist under the folder if nothing is
    found, so a bad path is obvious immediately instead of failing silently.
    """
    base = Path(messidor_dir)
    labels_path = base / "messidor_data.csv"
    if not labels_path.exists():
        print(f"  ⚠ No messidor_data.csv found in {messidor_dir}, skipping Messidor-2")
        return pd.DataFrame()

    labels = pd.read_csv(labels_path)

    if "adjudicated_gradable" in labels.columns:
        labels = labels[labels["adjudicated_gradable"] == 1]

    if sample_size:
        labels = labels.sample(min(sample_size, len(labels)), random_state=42)

    print("  Indexing Messidor-2 image files (one-time scan)...")
    file_index = {}
    for p in base.rglob("*"):
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS:
            file_index[p.name] = p
            file_index[p.name.lower()] = p  # tolerate case mismatches in the CSV too
    print(f"  Indexed {len(file_index)} image files")

    if len(file_index) == 0:
        # Diagnostic: show what's actually under this folder so a bad
        # MESSIDOR_DIR path (or unexpected extension) is obvious.
        ext_counts = Counter(p.suffix.lower() for p in base.rglob("*") if p.is_file())
        print(f"  ⚠ No images matched {IMAGE_EXTENSIONS}. Extensions actually found under {messidor_dir}:")
        for ext, count in ext_counts.most_common(10):
            print(f"      {ext or '(no extension)'}: {count}")
        print(f"  ⚠ Check MESSIDOR_DIR points at the folder that actually contains the image files "
              f"(sometimes they're nested a level or two deeper than expected).")
        return pd.DataFrame()

    rows = []
    n_missing = 0
    for _, row in tqdm(labels.iterrows(), total=len(labels), desc="Messidor-2"):
        filename = str(row["image_id"])
        img_path = file_index.get(filename) or file_index.get(filename.lower())
        if img_path is None:
            n_missing += 1
            continue
        feats = extract_vascular_features(img_path)
        if feats:
            grade = int(row["adjudicated_dr_grade"])
            feats.update(dataset="Messidor-2", image_id=filename, dr_grade=grade)
            rows.append(feats)

    if n_missing:
        print(f"  ⚠ {n_missing} filenames listed in messidor_data.csv had no matching image file on disk")

    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# Optional sanity-check model (NOT the real target — see module docstring)
# ----------------------------------------------------------------------------
def sanity_check_against_dr_grade(combined_df, output_dir):
    """
    This trains vessel-biomarker features -> DR grade purely as a sanity
    check that the extraction pipeline produces *some* discriminative
    signal. DR grade is not your actual research target (endothelial
    function / cortisol-driven vascular risk is), so don't read too much
    into this number either way. A weak score here doesn't mean the
    biomarkers are wrong for your hypothesis; a strong score doesn't
    validate your hypothesis either.
    """
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import classification_report, confusion_matrix
    import joblib

    feature_cols = [
        "vessel_density", "segment_count", "mean_caliber_px", "caliber_std_px",
        "avr_proxy", "mean_tortuosity", "tortuosity_std",
        "high_tortuosity_fraction", "fractal_dimension",
    ]
    df = combined_df.dropna(subset=feature_cols)
    if df["dr_grade"].nunique() < 2 or len(df) < 20:
        print("\n⚠ Not enough valid rows for a sanity-check model — skipping.")
        return None, None

    X = df[feature_cols].fillna(0)
    y = df["dr_grade"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    clf = RandomForestClassifier(n_estimators=300, max_depth=8, random_state=42, class_weight="balanced")
    clf.fit(X_train_scaled, y_train)

    preds = clf.predict(X_test_scaled)
    print("\n=== Sanity-check: vascular biomarkers -> DR grade (not the real target) ===")
    print(classification_report(y_test, preds))
    print("Confusion matrix:\n", confusion_matrix(y_test, preds))

    importances = pd.Series(clf.feature_importances_, index=feature_cols).sort_values(ascending=False)
    print("\nFeature importances:\n", importances)

    joblib.dump(clf, Path(output_dir) / "sanity_check_rf_model.joblib")
    joblib.dump(scaler, Path(output_dir) / "sanity_check_scaler.joblib")

    return clf, scaler


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("Extracting vascular biomarkers from EyePACS...")
    eyepacs_df = process_eyepacs(EYEPACS_DIR, SAMPLE_SIZE)

    print("Extracting vascular biomarkers from Messidor-2...")
    messidor_df = process_messidor(MESSIDOR_DIR, SAMPLE_SIZE)

    combined_df = pd.concat([eyepacs_df, messidor_df], ignore_index=True)
    if combined_df.empty:
        print("\n✗ No images processed. Check EYEPACS_DIR / MESSIDOR_DIR paths and folder structure.")
        return

    combined_csv = Path(OUTPUT_DIR) / "combined_vascular_biomarkers.csv"
    combined_df.to_csv(combined_csv, index=False)
    print(f"\n✓ Saved {len(combined_df)} rows to {combined_csv}")

    print("\n=== Biomarker summary (mean ± std across all processed images) ===")
    biomarker_cols = [
        "mean_caliber_px", "avr_proxy", "mean_tortuosity",
        "high_tortuosity_fraction", "fractal_dimension", "vessel_density",
    ]
    for col in biomarker_cols:
        vals = combined_df[col].dropna()
        if len(vals):
            print(f"  {col:28s} {vals.mean():8.3f} ± {vals.std():.3f}   (n={len(vals)})")
        else:
            print(f"  {col:28s} no valid values")

    if combined_df["dr_grade"].nunique() > 1:
        sanity_check_against_dr_grade(combined_df, OUTPUT_DIR)
    else:
        print("\n⚠ Only one DR grade class present in this sample — skipping sanity-check model.")


if __name__ == "__main__":
    main()
