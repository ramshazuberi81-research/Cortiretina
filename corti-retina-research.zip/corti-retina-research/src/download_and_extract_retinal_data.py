#!/usr/bin/env python3
"""
Kaggle Retinal Dataset Download & Extraction Pipeline
Extracts vessel metrics from fundus images for agent training
"""

import os
import sys
import pandas as pd
import numpy as np
import cv2
import json
from pathlib import Path
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("KAGGLE RETINAL DATASET EXTRACTION PIPELINE")
print("=" * 80)

# ============================================================================
# STEP 1: INSTALL REQUIRED PACKAGES
# ============================================================================

def install_dependencies():
    """Install required packages"""
    print("\n[STEP 1] Checking dependencies...")
    
    required_packages = {
        'kaggle': 'kaggle',
        'pandas': 'pandas',
        'numpy': 'numpy',
        'cv2': 'opencv-python',
        'PIL': 'pillow',
        'skimage': 'scikit-image',
        'sklearn': 'scikit-learn',
        'tqdm': 'tqdm'
    }
    
    missing = []
    for module, package in required_packages.items():
        try:
            __import__(module)
            print(f"  ✓ {package}")
        except ImportError:
            print(f"  ✗ {package} (installing...)")
            missing.append(package)
    
    if missing:
        os.system(f"pip install {' '.join(missing)} -q")
        print(f"  ✓ Installed {len(missing)} packages")
    
    return True

# ============================================================================
# STEP 2: KAGGLE AUTHENTICATION
# ============================================================================

def setup_kaggle_auth():
    """Setup Kaggle authentication"""
    print("\n[STEP 2] Kaggle Authentication Setup")
    
    kaggle_dir = Path.home() / '.kaggle'
    kaggle_json = kaggle_dir / 'kaggle.json'
    
    if kaggle_json.exists():
        print("  ✓ Kaggle credentials found")
        return True
    else:
        print("  ✗ Kaggle credentials NOT found")
        print("\n  To set up:")
        print("  1. Go to: https://www.kaggle.com/settings/account")
        print("  2. Click 'Create New API Token'")
        print("  3. Save kaggle.json to ~/.kaggle/")
        print("  4. Run: chmod 600 ~/.kaggle/kaggle.json")
        print("\n  Then run this script again.")
        return False

# ============================================================================
# STEP 3: DOWNLOAD DATASETS
# ============================================================================

def download_datasets(download_dir='./retinal_datasets'):
    """Download datasets from Kaggle"""
    print(f"\n[STEP 3] Downloading Datasets to {download_dir}")
    
    os.makedirs(download_dir, exist_ok=True)
    os.chdir(download_dir)
    
    datasets = {
        'eyepacs': 'eyepacs/diabetic-retinopathy-detection',
        'messidor2': 'eyepacs/messidor-2',
        'vessel_seg': 'ayush02102001/retinal-vessel-segmentation-dataset'
    }
    
    downloaded = {}
    
    for name, dataset_id in datasets.items():
        print(f"\n  Downloading {name}...")
        try:
            # Note: This requires Kaggle CLI to be installed and authenticated
            os.system(f'kaggle datasets download -d {dataset_id} --unzip -q')
            print(f"    ✓ {name} downloaded and extracted")
            downloaded[name] = True
        except Exception as e:
            print(f"    ✗ {name} failed: {e}")
            print(f"    Try manual download: https://kaggle.com/datasets/{dataset_id}")
            downloaded[name] = False
    
    os.chdir('..')
    return downloaded

# ============================================================================
# STEP 4: LOAD LABELS
# ============================================================================

def load_labels(dataset_dir='./retinal_datasets'):
    """Load all dataset labels"""
    print(f"\n[STEP 4] Loading Dataset Labels")
    
    labels = {}
    
    # EyePACS labels
    eyepacs_labels_file = Path(dataset_dir) / 'trainLabels.csv'
    if eyepacs_labels_file.exists():
        labels['eyepacs'] = pd.read_csv(eyepacs_labels_file)
        print(f"  ✓ EyePACS: {len(labels['eyepacs'])} images")
        print(f"    DR Grade Distribution:\n{labels['eyepacs']['level'].value_counts().sort_index()}\n")
    
    # Messidor-2 labels (if available)
    messidor_labels_file = Path(dataset_dir) / 'messidor_data.csv'
    if messidor_labels_file.exists():
        labels['messidor2'] = pd.read_csv(messidor_labels_file)
        print(f"  ✓ Messidor-2: {len(labels['messidor2'])} images")
    
    return labels

# ============================================================================
# STEP 5: EXTRACT VESSEL FEATURES
# ============================================================================

def extract_vessel_features(image_path):
    """
    Extract vascular features from fundus image using Frangi filter
    
    Returns dict with:
    - vessel_area: total vessel pixels
    - vessel_density: vessel pixels / total pixels
    - vessel_count: number of connected vessels
    - mean_vessel_width: average vessel width
    - image_entropy: complexity measure
    """
    try:
        from skimage.filters import frangi
        
        img = cv2.imread(str(image_path))
        if img is None:
            return None
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply CLAHE enhancement
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)
        
        # Detect vessels using Frangi filter
        vessel_mask = frangi(enhanced, sigmas=range(1, 10), alpha=0.5, beta=0.5)
        
        # Binarize
        vessel_binary = (vessel_mask > np.percentile(vessel_mask, 95)).astype(np.uint8) * 255
        
        # Extract metrics
        h, w = gray.shape
        vessel_area = np.sum(vessel_binary) / 255
        vessel_density = vessel_area / (h * w)
        
        # Count connected components (vessels)
        contours, _ = cv2.findContours(vessel_binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        vessel_count = len(contours)
        
        mean_vessel_width = vessel_area / max(vessel_count, 1)
        
        # Image entropy (quality measure)
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist.flatten() / hist.sum()
        entropy = -np.sum(hist * np.log2(hist + 1e-7))
        
        return {
            'vessel_area': vessel_area,
            'vessel_density': float(vessel_density),
            'vessel_count': int(vessel_count),
            'mean_vessel_width': float(mean_vessel_width),
            'image_entropy': float(entropy),
            'image_valid': True
        }
    
    except Exception as e:
        return {
            'vessel_area': 0,
            'vessel_density': 0,
            'vessel_count': 0,
            'mean_vessel_width': 0,
            'image_entropy': 0,
            'image_valid': False,
            'error': str(e)
        }

# ============================================================================
# STEP 6: PROCESS DATASETS
# ============================================================================

def process_eyepacs(labels, dataset_dir='./retinal_datasets', sample_size=None):
    """Process EyePACS dataset"""
    print(f"\n[STEP 5a] Processing EyePACS Images")
    
    results = []
    image_dir = Path(dataset_dir) / 'train'
    
    if not image_dir.exists():
        print(f"  ✗ EyePACS training directory not found: {image_dir}")
        return pd.DataFrame()
    
    # Use sample if specified
    process_labels = labels if sample_size is None else labels.sample(min(sample_size, len(labels)))
    
    pbar = tqdm(process_labels.iterrows(), total=len(process_labels), desc="  Extracting features")
    
    for idx, row in pbar:
        image_path = image_dir / f"{row['image']}.jpeg"
        
        if image_path.exists():
            features = extract_vessel_features(image_path)
            if features and features['image_valid']:
                features['dataset'] = 'EyePACS'
                features['image_id'] = row['image']
                features['dr_grade'] = int(row['level'])
                results.append(features)
    
    df = pd.DataFrame(results)
    print(f"  ✓ Extracted features from {len(df)} valid images")
    
    return df

def process_messidor2(labels, dataset_dir='./retinal_datasets', sample_size=None):
    """Process Messidor-2 dataset"""
    print(f"\n[STEP 5b] Processing Messidor-2 Images")
    
    results = []
    image_dir = Path(dataset_dir) / 'Base12'
    
    if not image_dir.exists():
        print(f"  ✗ Messidor-2 directory not found: {image_dir}")
        return pd.DataFrame()
    
    # Use sample if specified
    process_labels = labels if sample_size is None else labels.sample(min(sample_size, len(labels)))
    
    pbar = tqdm(process_labels.iterrows(), total=len(process_labels), desc="  Extracting features")
    
    for idx, row in pbar:
        # Handle different possible filename columns
        filename = row.get('filename') or row.get('image') or row.get('file')
        
        image_path = image_dir / filename
        
        if image_path.exists():
            features = extract_vessel_features(image_path)
            if features and features['image_valid']:
                features['dataset'] = 'Messidor-2'
                features['image_id'] = filename
                features['dr_grade'] = int(row.get('DR_grade', row.get('level', 0)))
                results.append(features)
    
    df = pd.DataFrame(results)
    print(f"  ✓ Extracted features from {len(df)} valid images")
    
    return df

# ============================================================================
# STEP 7: COMBINE & ANALYZE
# ============================================================================

def combine_and_analyze(eyepacs_df, messidor2_df):
    """Combine datasets and generate statistics"""
    print(f"\n[STEP 6] Combining Datasets & Analysis")
    
    combined = pd.concat([eyepacs_df, messidor2_df], ignore_index=True)
    
    print(f"\n  Combined Dataset Summary:")
    print(f"  ├─ Total images: {len(combined)}")
    print(f"  ├─ EyePACS: {len(eyepacs_df)}")
    print(f"  ├─ Messidor-2: {len(messidor2_df)}")
    print(f"\n  Feature Statistics by DR Grade:")
    
    # Group by DR grade
    for dr_grade in sorted(combined['dr_grade'].unique()):
        subset = combined[combined['dr_grade'] == dr_grade]
        print(f"\n    DR Grade {dr_grade} ({len(subset)} images):")
        print(f"      Vessel Density: {subset['vessel_density'].mean():.4f} ± {subset['vessel_density'].std():.4f}")
        print(f"      Vessel Count: {subset['vessel_count'].mean():.0f} ± {subset['vessel_count'].std():.0f}")
        print(f"      Mean Width: {subset['mean_vessel_width'].mean():.2f} ± {subset['mean_vessel_width'].std():.2f}")
        print(f"      Image Entropy: {subset['image_entropy'].mean():.2f} ± {subset['image_entropy'].std():.2f}")
    
    return combined

# ============================================================================
# STEP 8: SAVE FOR AGENTS
# ============================================================================

def prepare_agent_data(combined_df):
    """Prepare data structures for agent system"""
    print(f"\n[STEP 7] Preparing Agent-Ready Datasets")
    
    from sklearn.preprocessing import StandardScaler
    
    # Select features
    feature_cols = ['vessel_area', 'vessel_density', 'vessel_count', 
                    'mean_vessel_width', 'image_entropy']
    
    X = combined_df[feature_cols].fillna(0)
    y = combined_df['dr_grade']
    
    # Normalize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Save as NumPy
    np.save('vessel_features_normalized.npy', X_scaled)
    np.save('dr_labels.npy', y.values)
    print("  ✓ Saved: vessel_features_normalized.npy, dr_labels.npy")
    
    # Save as JSON for API/agent use
    agent_data = {
        'metadata': {
            'total_samples': len(combined_df),
            'feature_names': feature_cols,
            'dr_grades': {0: 'Normal', 1: 'Mild', 2: 'Moderate', 3: 'Severe', 4: 'Proliferative'},
            'scaler_mean': scaler.mean_.tolist(),
            'scaler_std': scaler.scale_.tolist()
        },
        'features': X_scaled.tolist(),
        'labels': y.tolist(),
        'images': combined_df[['image_id', 'dataset', 'dr_grade']].to_dict(orient='records')
    }
    
    with open('agent_vessel_data.json', 'w') as f:
        json.dump(agent_data, f, indent=2)
    print("  ✓ Saved: agent_vessel_data.json")
    
    return X_scaled, y.values, scaler

# ============================================================================
# STEP 9: VISUALIZATION
# ============================================================================

def create_visualizations(combined_df):
    """Create summary visualizations"""
    print(f"\n[STEP 8] Creating Visualizations")
    
    try:
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # 1. DR Grade Distribution
        combined_df['dr_grade'].value_counts().sort_index().plot(kind='bar', ax=axes[0, 0])
        axes[0, 0].set_title('DR Grade Distribution')
        axes[0, 0].set_xlabel('DR Grade')
        axes[0, 0].set_ylabel('Count')
        
        # 2. Vessel Density by DR Grade
        combined_df.boxplot(column='vessel_density', by='dr_grade', ax=axes[0, 1])
        axes[0, 1].set_title('Vessel Density by DR Grade')
        axes[0, 1].set_xlabel('DR Grade')
        
        # 3. Vessel Count by DR Grade
        combined_df.boxplot(column='vessel_count', by='dr_grade', ax=axes[1, 0])
        axes[1, 0].set_title('Vessel Count by DR Grade')
        axes[1, 0].set_xlabel('DR Grade')
        
        # 4. Dataset split
        combined_df['dataset'].value_counts().plot(kind='bar', ax=axes[1, 1])
        axes[1, 1].set_title('Dataset Distribution')
        axes[1, 1].set_xlabel('Dataset')
        axes[1, 1].set_ylabel('Count')
        
        plt.tight_layout()
        plt.savefig('retinal_dataset_summary.png', dpi=100)
        print("  ✓ Saved: retinal_dataset_summary.png")
        plt.close()
        
    except Exception as e:
        print(f"  ⚠ Visualization failed: {e}")

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """Main execution pipeline"""
    
    try:
        # Step 1: Install dependencies
        install_dependencies()
        
        # Step 2: Check Kaggle auth
        if not setup_kaggle_auth():
            print("\n⚠ Skipping download. Please set up Kaggle credentials first.")
            print("You can manually download from:")
            print("  - https://www.kaggle.com/datasets/eyepacs/diabetic-retinopathy-detection")
            print("  - https://www.kaggle.com/datasets/eyepacs/messidor-2")
            return
        
        # Step 3: Download datasets
        download_dir = './retinal_datasets'
        downloaded = download_datasets(download_dir)
        
        # Step 4: Load labels
        labels = load_labels(download_dir)
        
        if not labels:
            print("\n✗ No labels found. Please ensure datasets are downloaded.")
            return
        
        # Step 5: Process images
        # Using sample_size to limit processing (remove for full dataset)
        sample_size = 200  # Change to None for full dataset
        
        eyepacs_df = process_eyepacs(labels['eyepacs'], download_dir, sample_size=sample_size)
        messidor2_df = process_messidor2(labels.get('messidor2', pd.DataFrame()), 
                                         download_dir, sample_size=sample_size)
        
        # Step 6: Combine and analyze
        combined_df = combine_and_analyze(eyepacs_df, messidor2_df)
        
        # Save raw combined data
        combined_df.to_csv('combined_retinal_features.csv', index=False)
        print("\n  ✓ Saved: combined_retinal_features.csv")
        
        # Step 7: Prepare for agents
        X_scaled, y, scaler = prepare_agent_data(combined_df)
        
        # Step 8: Create visualizations
        create_visualizations(combined_df)
        
        print("\n" + "=" * 80)
        print("✓ EXTRACTION COMPLETE")
        print("=" * 80)
        print("\nGenerated Files:")
        print("  • combined_retinal_features.csv - Full dataset with extracted features")
        print("  • agent_vessel_data.json - Agent-ready format")
        print("  • vessel_features_normalized.npy - Normalized features")
        print("  • dr_labels.npy - DR grades")
        print("  • retinal_dataset_summary.png - Summary visualization")
        print("\nNext steps:")
        print("  1. Use agent_vessel_data.json for your agent system")
        print("  2. Train calibration agents on vessel_features_normalized.npy")
        print("  3. Map vessel metrics to CVD risk prediction")
        
    except KeyboardInterrupt:
        print("\n\n⚠ Process interrupted by user")
    except Exception as e:
        print(f"\n\n✗ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
