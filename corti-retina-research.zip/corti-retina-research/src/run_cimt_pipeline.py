#!/usr/bin/env python3
"""
China-Fundus-CIMT training pipeline.

Reuses extract_vascular_features() from run_local_pipeline_v2.py (caliber,
AVR-proxy, tortuosity, fractal dimension) and trains against a REAL
cardiovascular-risk proxy this time: carotid intima-media thickness (CIMT)
thickened vs. normal, instead of DR grade. This is meaningfully closer to
your actual hypothesis than the DR-grade sanity check was, but it's still
not the real target — no cortisol/hypercortisolism data, no flicker-light
dynamic response, no direct CVD outcome (stroke/MI) label. See the
run_local_pipeline_v2.py docstring for the fuller list of what's still
missing.

STEP 1 — RUN IN INSPECT MODE FIRST.
I don't have the exact JSON key names from the dataset's metadata file
(the paper describes the fields conceptually — patient ID, CIMT group,
age, gender — but not their literal key strings). Set INSPECT_ONLY = True
and run this once; it will print the structure of one record so you can
fill in the correct key names below. Then set INSPECT_ONLY = False.

EDIT THESE FOR YOUR MACHINE:
"""
CIMT_IMAGE_DIR = "./data/china_fundus_cimt/images"     # folder containing PatientID_L.png / PatientID_R.png
CIMT_JSON_PATH = "./data/china_fundus_cimt/data_info.json"  # the metadata JSON from Figshare
SAMPLE_SIZE    = 300          # None = process everything; start small to test
OUTPUT_DIR     = "./outputs"
INSPECT_ONLY   = True         # <-- run this first, then flip to False

# --- Fill these in after inspecting the JSON (see INSPECT_ONLY output) ---
JSON_LABEL_KEY  = "cimt_group"   # placeholder — replace with the real key for thickened/normal
JSON_AGE_KEY    = "age"          # placeholder
JSON_GENDER_KEY = "gender"       # placeholder
THICKENED_VALUE = "thickened"    # placeholder — whatever string/int marks the thickened group in the JSON

import os
import sys
import json
import warnings
from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd
from tqdm import tqdm

warnings.filterwarnings("ignore")

# Reuse the biomarker extractor from the previous script rather than
# duplicating it — keep both files in the same folder.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_local_pipeline_v2 import extract_vascular_features


def inspect_json(json_path, n=2):
    with open(json_path, "r") as f:
        data = json.load(f)

    print(f"Top-level type: {type(data)}")
    if isinstance(data, dict):
        print(f"Number of patient entries: {len(data)}")
        sample_keys = list(data.keys())[:n]
        for k in sample_keys:
            print(f"\n--- Sample entry: patient_id = {k} ---")
            print(json.dumps(data[k], indent=2, default=str))
    elif isinstance(data, list):
        print(f"Number of entries: {len(data)}")
        for row in data[:n]:
            print("\n--- Sample entry ---")
            print(json.dumps(row, indent=2, default=str))
    print(
        "\n>>> Find the key names for the CIMT thickened/normal label, age, and "
        "gender above, then set JSON_LABEL_KEY / JSON_AGE_KEY / JSON_GENDER_KEY / "
        "THICKENED_VALUE at the top of this script accordingly, flip INSPECT_ONLY "
        "to False, and re-run."
    )


def load_cimt_metadata(json_path):
    """
    Returns a dict: patient_id -> {"label": 0/1, "age": float or None, "gender": str or None}
    Handles both dict-of-records and list-of-records JSON shapes.
    """
    with open(json_path, "r") as f:
        data = json.load(f)

    records = {}
    items = data.items() if isinstance(data, dict) else enumerate(data)
    for pid, rec in items:
        if not isinstance(rec, dict):
            continue
        patient_id = rec.get("patient_id", pid)
        label_raw = rec.get(JSON_LABEL_KEY)
        if label_raw is None:
            continue
        label = 1 if str(label_raw).lower() == str(THICKENED_VALUE).lower() else 0
        records[str(patient_id)] = {
            "label": label,
            "age": rec.get(JSON_AGE_KEY),
            "gender": rec.get(JSON_GENDER_KEY),
        }
    return records


def find_patient_images(image_dir, patient_id):
    """
    Dataset naming convention per the paper: PatientID_L.png / PatientID_R.png
    Returns a list of (eye, path) tuples for whichever exist.
    """
    base = Path(image_dir)
    found = []
    for eye, suffix in (("L", "_L.png"), ("R", "_R.png")):
        p = base / f"{patient_id}{suffix}"
        if p.exists():
            found.append((eye, p))
    return found


def process_cimt_dataset(image_dir, json_path, sample_size=None):
    metadata = load_cimt_metadata(json_path)
    print(f"  Loaded metadata for {len(metadata)} patients")

    label_dist = Counter(v["label"] for v in metadata.values())
    print(f"  Label distribution: normal={label_dist.get(0,0)}, thickened={label_dist.get(1,0)}")

    patient_ids = list(metadata.keys())
    if sample_size:
        # Stratified sample so both classes are represented, same approach
        # as the EyePACS stratified sampling in v2.
        import random
        random.seed(42)
        by_label = {0: [], 1: []}
        for pid in patient_ids:
            by_label[metadata[pid]["label"]].append(pid)
        per_class_target = max(sample_size // 2, 1)
        sampled = []
        for label, ids in by_label.items():
            random.shuffle(ids)
            sampled.extend(ids[:per_class_target])
        random.shuffle(sampled)
        patient_ids = sampled
        print(f"  Stratified sample: {len(patient_ids)} patients (~{per_class_target} per class)")

    rows = []
    n_missing_images = 0
    for pid in tqdm(patient_ids, desc="China-Fundus-CIMT"):
        images = find_patient_images(image_dir, pid)
        if not images:
            n_missing_images += 1
            continue
        meta = metadata[pid]
        for eye, img_path in images:
            feats = extract_vascular_features(img_path)
            if feats:
                feats.update(
                    patient_id=pid,
                    eye=eye,
                    cimt_thickened=meta["label"],
                    age=meta["age"],
                    gender=meta["gender"],
                )
                rows.append(feats)

    if n_missing_images:
        print(f"  ⚠ {n_missing_images} patients in the JSON had no matching image file "
              f"under {image_dir} — check the filename pattern / path.")

    return pd.DataFrame(rows)


def train_cimt_model(df, output_dir):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
    import joblib

    vascular_cols = [
        "vessel_density", "segment_count", "mean_caliber_px", "caliber_std_px",
        "avr_proxy", "mean_tortuosity", "tortuosity_std",
        "high_tortuosity_fraction", "fractal_dimension",
    ]

    df = df.dropna(subset=vascular_cols)
    if len(df) < 20 or df["cimt_thickened"].nunique() < 2:
        print("\n⚠ Not enough valid rows / only one class present — can't train. "
              "Check extraction success rate and label distribution above.")
        return None, None

    # Optional: fold in age (this dataset actually has it, unlike EyePACS/Messidor-2)
    feature_cols = vascular_cols.copy()
    if "age" in df.columns and df["age"].notna().any():
        feature_cols.append("age")

    X = df[feature_cols].fillna(df[feature_cols].median())
    y = df["cimt_thickened"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    clf = RandomForestClassifier(
        n_estimators=300, max_depth=8, random_state=42, class_weight="balanced"
    )
    clf.fit(X_train_scaled, y_train)

    preds = clf.predict(X_test_scaled)
    probs = clf.predict_proba(X_test_scaled)[:, 1]

    print("\n=== CIMT thickened/normal classification (vascular biomarkers) ===")
    print(classification_report(y_test, preds, target_names=["normal", "thickened"]))
    print("Confusion matrix:\n", confusion_matrix(y_test, preds))
    print(f"ROC-AUC: {roc_auc_score(y_test, probs):.3f}")

    importances = pd.Series(clf.feature_importances_, index=feature_cols).sort_values(ascending=False)
    print("\nFeature importances:\n", importances)

    joblib.dump(clf, Path(output_dir) / "cimt_rf_model.joblib")
    joblib.dump(scaler, Path(output_dir) / "cimt_feature_scaler.joblib")
    print(f"\n  ✓ Saved model: {output_dir}/cimt_rf_model.joblib")
    print(f"  ✓ Saved scaler: {output_dir}/cimt_feature_scaler.joblib")

    return clf, scaler


def main():
    if INSPECT_ONLY:
        print(f"Inspecting {CIMT_JSON_PATH} ...\n")
        inspect_json(CIMT_JSON_PATH)
        return

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("Extracting vascular biomarkers from China-Fundus-CIMT...")
    df = process_cimt_dataset(CIMT_IMAGE_DIR, CIMT_JSON_PATH, SAMPLE_SIZE)

    if df.empty:
        print("\n✗ No images processed. Check CIMT_IMAGE_DIR / CIMT_JSON_PATH and the "
              "JSON key names at the top of this script.")
        return

    out_csv = Path(OUTPUT_DIR) / "cimt_vascular_biomarkers.csv"
    df.to_csv(out_csv, index=False)
    print(f"\n✓ Saved {len(df)} rows to {out_csv}")

    print("\n=== Biomarker summary by CIMT group ===")
    biomarker_cols = ["mean_caliber_px", "avr_proxy", "mean_tortuosity",
                       "high_tortuosity_fraction", "fractal_dimension"]
    for col in biomarker_cols:
        for label, name in ((0, "normal"), (1, "thickened")):
            vals = df.loc[df["cimt_thickened"] == label, col].dropna()
            if len(vals):
                print(f"  {col:28s} [{name:9s}] {vals.mean():8.3f} ± {vals.std():.3f}  (n={len(vals)})")

    train_cimt_model(df, OUTPUT_DIR)


if __name__ == "__main__":
    main()
