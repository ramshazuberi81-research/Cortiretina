#!/usr/bin/env python3
"""
Cortisol-Induced Vascular Pathology Mapper
Uses diabetic retinopathy lesion patterns as a model for understanding
cortisol-induced endothelial dysfunction and vascular changes

Key insight: Both diabetes AND chronic hypercortisolism cause vascular damage
through different mechanisms (hyperglycemia vs. endothelial dysfunction),
but the *observable vascular pathology* follows similar patterns.

This framework maps cortisol levels to DR-like vascular signatures.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Dict, List, Tuple
from enum import Enum

# ============================================================================
# LESION TAXONOMY: DR as Model for Vascular Pathology
# ============================================================================

class VascularLesionType(Enum):
    """
    DR lesion types re-interpreted as vascular damage markers
    
    What each means in both DM and hypercortisolism:
    """
    
    MICROANEURYSM = {
        'code': 'MA',
        'description': 'Small vessel outpouching',
        'dm_cause': 'Pericyte loss, BM thickening',
        'cortisol_cause': 'Endothelial dysfunction, NO loss',
        'severity': 1,
        'reversibility': 'Partially (if cortisol corrected)'
    }
    
    HEMORRHAGE = {
        'code': 'H',
        'description': 'Vessel rupture, blood leak',
        'dm_cause': 'Vessel wall weakening',
        'cortisol_cause': 'Increased vascular fragility + reduced collagen',
        'severity': 2,
        'reversibility': 'Slow (structural damage)'
    }
    
    COTTON_WOOL_SPOT = {
        'code': 'CWS',
        'description': 'Nerve fiber layer infarct',
        'dm_cause': 'Capillary occlusion, hypoxia',
        'cortisol_cause': 'Reduced perfusion from endothelial dysfunction',
        'severity': 2,
        'reversibility': 'Yes (ischemic, not structural)'
    }
    
    VENOUS_BEADING = {
        'code': 'VB',
        'description': 'Irregular vessel caliber (alternating dilations)',
        'dm_cause': 'Local hypoxia → compensation',
        'cortisol_cause': 'Impaired vasoreactivity, lost tone regulation',
        'severity': 2,
        'reversibility': 'Yes (functional deficit)'
    }
    
    NEOVASCULARIZATION = {
        'code': 'NV',
        'description': 'Abnormal new vessel growth',
        'dm_cause': 'VEGF response to chronic hypoxia',
        'cortisol_cause': 'Rare; indicates severe chronic damage',
        'severity': 3,
        'reversibility': 'No (structural remodeling)'
    }
    
    EXUDATE = {
        'code': 'EX',
        'description': 'Lipid/protein leakage (yellow-white deposits)',
        'dm_cause': 'Vessel permeability ↑, BRB breakdown',
        'cortisol_cause': 'Loss of endothelial tight junctions, BBB breach',
        'severity': 1,
        'reversibility': 'Yes (if cause stops)'
    }


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class LesionLoad:
    """Quantifies each lesion type in an image"""
    microaneurysms: int = 0
    hemorrhages: int = 0
    cotton_wool_spots: int = 0
    venous_beading: int = 0
    neovascularization: int = 0
    exudates: int = 0
    
    def total_lesions(self) -> int:
        """Total lesion count"""
        return (self.microaneurysms + self.hemorrhages + self.cotton_wool_spots +
                self.venous_beading + self.neovascularization + self.exudates)
    
    def severity_score(self) -> float:
        """Weighted severity (1-3 scale per lesion type)"""
        weights = {
            'ma': 1 * self.microaneurysms,
            'h': 2 * self.hemorrhages,
            'cws': 2 * self.cotton_wool_spots,
            'vb': 2 * self.venous_beading,
            'nv': 3 * self.neovascularization,
            'ex': 1 * self.exudates
        }
        total_weighted = sum(weights.values())
        if self.total_lesions() == 0:
            return 0
        return total_weighted / self.total_lesions()
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for storage"""
        return {
            'microaneurysms': self.microaneurysms,
            'hemorrhages': self.hemorrhages,
            'cotton_wool_spots': self.cotton_wool_spots,
            'venous_beading': self.venous_beading,
            'neovascularization': self.neovascularization,
            'exudates': self.exudates,
            'total_lesions': self.total_lesions(),
            'severity_score': self.severity_score()
        }


@dataclass
class CortisolVascularProfile:
    """
    Patient profile combining cortisol level with vascular damage signature
    """
    patient_id: str
    cortisol_level_ug_dl: float  # μg/dL (normal: 5-23 am, 3-16 pm)
    cortisol_status: str  # 'normal', 'mild_elevation', 'significant', 'severe'
    
    # Vessel metrics (extracted from retinal imaging)
    vessel_density: float
    vessel_width: float
    arteriolar_venular_ratio: float  # AVR, normal ~1.0
    
    # Lesion load
    lesion_load: LesionLoad
    
    # DR-equivalent classification
    dr_grade_equivalent: int  # 0-4 mapped from vascular damage
    
    # Reversibility assessment
    days_since_cortisol_elevation: int = 0
    cortisol_control_achieved: bool = False
    
    def cortisol_risk_category(self) -> str:
        """Map cortisol to endothelial risk"""
        if self.cortisol_level_ug_dl < 23:
            return 'Normal'
        elif self.cortisol_level_ug_dl < 35:
            return 'Mild elevation (endothelial stress)'
        elif self.cortisol_level_ug_dl < 50:
            return 'Significant (clear dysfunction)'
        else:
            return 'Severe (acute pathology)'


# ============================================================================
# AGENT: DR SIGNATURE ENCODER
# ============================================================================

class DRSignatureEncoder:
    """
    Learns vascular pathology patterns from DR dataset
    Creates a 'lesion fingerprint' for each DR grade
    """
    
    def __init__(self):
        self.dr_signatures = {}  # {grade: mean_lesion_load}
        self.lesion_frequency = {}  # {grade: {lesion_type: %}}
        self.vessel_metrics_by_grade = {}  # {grade: {metric: mean}}
    
    def train_on_dr_data(self, dr_dataframe: pd.DataFrame):
        """
        Learn lesion patterns from DR dataset
        Assumes df has columns: dr_grade, microaneurysms, hemorrhages, etc.
        """
        print("[AGENT] Training DR Signature Encoder")
        
        for dr_grade in sorted(dr_dataframe['dr_grade'].unique()):
            subset = dr_dataframe[dr_dataframe['dr_grade'] == dr_grade]
            
            # Average lesion load
            self.dr_signatures[dr_grade] = {
                'ma_mean': subset['microaneurysms'].mean() if 'microaneurysms' in subset else 0,
                'h_mean': subset['hemorrhages'].mean() if 'hemorrhages' in subset else 0,
                'cws_mean': subset['cotton_wool_spots'].mean() if 'cotton_wool_spots' in subset else 0,
                'vb_mean': subset['venous_beading'].mean() if 'venous_beading' in subset else 0,
                'nv_mean': subset['neovascularization'].mean() if 'neovascularization' in subset else 0,
                'ex_mean': subset['exudates'].mean() if 'exudates' in subset else 0,
            }
            
            # Vessel metrics
            self.vessel_metrics_by_grade[dr_grade] = {
                'vessel_density': subset['vessel_density'].mean() if 'vessel_density' in subset else 0,
                'vessel_density_std': subset['vessel_density'].std() if 'vessel_density' in subset else 0,
                'mean_vessel_width': subset['mean_vessel_width'].mean() if 'mean_vessel_width' in subset else 0,
                'mean_vessel_width_std': subset['mean_vessel_width'].std() if 'mean_vessel_width' in subset else 0,
            }
            
            print(f"  DR Grade {dr_grade}: {subset.shape[0]} images")
            print(f"    Microaneurysms: {self.dr_signatures[dr_grade]['ma_mean']:.2f}")
            print(f"    Hemorrhages: {self.dr_signatures[dr_grade]['h_mean']:.2f}")
            print(f"    Vessel density: {self.vessel_metrics_by_grade[dr_grade]['vessel_density']:.4f}")
    
    def get_dr_signature(self, dr_grade: int) -> Dict:
        """Get average lesion pattern for a DR grade"""
        return self.dr_signatures.get(dr_grade, {})
    
    def get_vessel_metrics(self, dr_grade: int) -> Dict:
        """Get typical vessel metrics for a DR grade"""
        return self.vessel_metrics_by_grade.get(dr_grade, {})


# ============================================================================
# AGENT: CORTISOL-TO-VASCULAR MAPPER
# ============================================================================

class CortisolVascularMapper:
    """
    Maps cortisol levels to predicted vascular pathology
    WITHOUT assuming the patient has diabetes
    
    Core hypothesis: Cortisol causes endothelial dysfunction → 
    vascular changes that mimic (but don't perfectly replicate) DR
    """
    
    def __init__(self, dr_encoder: DRSignatureEncoder):
        self.dr_encoder = dr_encoder
        self.cortisol_lesion_mapping = self._build_cortisol_lesion_mapping()
    
    def _build_cortisol_lesion_mapping(self) -> Dict:
        """
        Cortisol's vascular effects map to specific lesion types
        
        Mechanism: Cortisol suppresses NO → impaired vasodilation +
        increased vascular permeability + reduced endothelial stability
        """
        
        return {
            # Low elevation (5-30 μg/dL) — mostly functional
            'mild': {
                'exudates': 0.5,          # Early BBB/BRB leakage
                'microaneurysms': 0.1,    # Occasional endothelial breaks
                'cotton_wool_spots': 0.2, # Early ischemia from poor vasoreactivity
                'hemorrhages': 0,         # Rare at this stage
                'venous_beading': 0.1,    # Some dysrhythmia
                'neovascularization': 0
            },
            
            # Moderate elevation (30-50 μg/dL) — functional + structural
            'moderate': {
                'exudates': 1.2,
                'microaneurysms': 0.4,
                'cotton_wool_spots': 0.6,
                'hemorrhages': 0.1,
                'venous_beading': 0.3,
                'neovascularization': 0
            },
            
            # Severe (50+ μg/dL) — significant damage
            'severe': {
                'exudates': 2.5,
                'microaneurysms': 1.0,
                'cotton_wool_spots': 1.5,
                'hemorrhages': 0.3,
                'venous_beading': 0.8,
                'neovascularization': 0.1  # Very rare, only chronic severe cases
            }
        }
    
    def estimate_lesion_load_from_cortisol(self, cortisol_level: float, 
                                          duration_months: int = 1) -> Tuple[LesionLoad, str]:
        """
        Predict lesion load from cortisol level
        
        Args:
            cortisol_level: μg/dL (normal 5-23)
            duration_months: How long elevated
        
        Returns:
            (predicted_lesion_load, cortisol_category)
        """
        
        # Categorize cortisol
        if cortisol_level < 25:
            category = 'normal'
            factor = 0
        elif cortisol_level < 35:
            category = 'mild'
            factor = (cortisol_level - 25) / 10  # Linear ramp 0-1
        elif cortisol_level < 50:
            category = 'moderate'
            factor = 1 + (cortisol_level - 35) / 15  # Ramp 1-2
        else:
            category = 'severe'
            factor = 2 + (cortisol_level - 50) / 30  # Ramp 2-3
        
        # Duration multiplier (lesions accumulate over time)
        # Assumes linear accumulation; could be exponential
        duration_multiplier = 1 + (min(duration_months, 24) / 24) * 0.5  # Max +50% over 2 years
        
        # Get template for this category
        if category == 'normal':
            template = {}
        else:
            template = self.cortisol_lesion_mapping.get(category, {})
        
        # Generate predicted lesion load
        predicted = LesionLoad(
            microaneurysms=int(template.get('microaneurysms', 0) * factor * duration_multiplier),
            hemorrhages=int(template.get('hemorrhages', 0) * factor * duration_multiplier),
            cotton_wool_spots=int(template.get('cotton_wool_spots', 0) * factor * duration_multiplier),
            venous_beading=int(template.get('venous_beading', 0) * factor * duration_multiplier),
            neovascularization=int(template.get('neovascularization', 0) * factor * duration_multiplier),
            exudates=int(template.get('exudates', 0) * factor * duration_multiplier)
        )
        
        return predicted, category
    
    def map_cortisol_to_dr_equivalent(self, cortisol_level: float, 
                                     vessel_metrics: Dict) -> Tuple[int, Dict]:
        """
        Map cortisol-induced vascular changes to a DR grade equivalent
        
        Even though the patient doesn't have diabetes, their vascular
        damage *looks like* a certain DR grade.
        
        Returns:
            (dr_grade_equivalent, explanation_dict)
        """
        
        # Step 1: Estimate lesion load
        lesion_load, category = self.estimate_lesion_load_from_cortisol(cortisol_level)
        
        # Step 2: Compare to DR signatures
        best_match_grade = 0
        best_match_distance = float('inf')
        
        for dr_grade in range(5):
            dr_sig = self.dr_encoder.get_dr_signature(dr_grade)
            
            if not dr_sig:
                continue
            
            # Simple distance metric: sum absolute differences in lesion types
            distance = abs(lesion_load.microaneurysms - dr_sig.get('ma_mean', 0))
            distance += abs(lesion_load.hemorrhages - dr_sig.get('h_mean', 0))
            distance += abs(lesion_load.exudates - dr_sig.get('ex_mean', 0))
            
            if distance < best_match_distance:
                best_match_distance = distance
                best_match_grade = dr_grade
        
        # Step 3: Vessel metric comparison
        vessel_metrics_at_grade = self.dr_encoder.get_vessel_metrics(best_match_grade)
        
        explanation = {
            'cortisol_level': cortisol_level,
            'cortisol_category': category,
            'predicted_lesion_load': lesion_load.to_dict(),
            'dr_grade_equivalent': best_match_grade,
            'dr_equivalent_interpretation': self._interpret_dr_grade(best_match_grade),
            'vessel_density_expected': vessel_metrics_at_grade.get('vessel_density', None),
            'vessel_width_expected': vessel_metrics_at_grade.get('mean_vessel_width', None),
            'key_difference': 'No hyperglycemia; damage is purely from endothelial dysfunction'
        }
        
        return best_match_grade, explanation
    
    def _interpret_dr_grade(self, grade: int) -> str:
        """Interpret DR grade for cortisol context"""
        interpretations = {
            0: 'No vascular changes (normal)',
            1: 'Mild changes: Early endothelial leakage, minimal structural damage',
            2: 'Moderate: Significant lesions, some vessel instability, CVD risk emerging',
            3: 'Severe: Widespread damage, vessel occlusions possible, high CVD risk',
            4: 'Proliferative: Structural remodeling, critical CVD risk'
        }
        return interpretations.get(grade, 'Unknown')


# ============================================================================
# AGENT: REVERSIBILITY PREDICTOR
# ============================================================================

class ReversibilityPredictor:
    """
    Predicts if cortisol-induced vascular changes are reversible
    after cortisol control (e.g., via metyrapone)
    
    Key: Different lesion types have different reversibility
    """
    
    # Reversibility estimates (% recovery expected after cortisol normalization)
    REVERSIBILITY_MATRIX = {
        'microaneurysms': {
            'timeline_weeks': 8,
            'recovery_percent': 60,  # Many resorb with restored NO
            'mechanism': 'Endothelial stabilization, restored NO signaling'
        },
        'hemorrhages': {
            'timeline_weeks': 12,
            'recovery_percent': 20,  # Slow resorption, structural damage
            'mechanism': 'Resorption, scar formation'
        },
        'cotton_wool_spots': {
            'timeline_weeks': 6,
            'recovery_percent': 100, # Ischemic; reverses if perfusion restores
            'mechanism': 'Reperfusion, nerve fiber recovery'
        },
        'venous_beading': {
            'timeline_weeks': 4,
            'recovery_percent': 80,  # Vasoreactivity returns
            'mechanism': 'Restored endothelial tone, NO-dependent relaxation'
        },
        'exudates': {
            'timeline_weeks': 6,
            'recovery_percent': 90,  # BBB/BRB sealing
            'mechanism': 'Tight junction restoration'
        },
        'neovascularization': {
            'timeline_weeks': 52,
            'recovery_percent': 5,   # Essentially permanent
            'mechanism': 'Structural remodeling; regression is rare'
        }
    }
    
    def predict_recovery(self, lesion_load: LesionLoad, 
                        weeks_since_cortisol_control: int) -> Dict:
        """
        Predict recovery trajectory after cortisol normalization
        """
        
        total_lesions_baseline = lesion_load.total_lesions()
        
        recovery_projection = {}
        overall_recovery = 0
        
        lesion_types = {
            'microaneurysms': lesion_load.microaneurysms,
            'hemorrhages': lesion_load.hemorrhages,
            'cotton_wool_spots': lesion_load.cotton_wool_spots,
            'venous_beading': lesion_load.venous_beading,
            'exudates': lesion_load.exudates,
            'neovascularization': lesion_load.neovascularization
        }
        
        for lesion_type, count in lesion_types.items():
            if count == 0:
                continue
            
            rev_data = self.REVERSIBILITY_MATRIX[lesion_type]
            
            # Recovery progress: sigmoidal curve
            # Reaches plateau at timeline_weeks
            progress = min(1.0, weeks_since_cortisol_control / rev_data['timeline_weeks'])
            
            # Expected lesions remaining
            expected_recovery_fraction = rev_data['recovery_percent'] / 100 * progress
            remaining = count * (1 - expected_recovery_fraction)
            
            recovery_projection[lesion_type] = {
                'baseline': count,
                'expected_remaining': round(remaining),
                'expected_recovery': count - round(remaining),
                'recovery_percent_expected': expected_recovery_fraction * 100,
                'timeline_weeks': rev_data['timeline_weeks'],
                'mechanism': rev_data['mechanism']
            }
            
            overall_recovery += (count - round(remaining))
        
        return {
            'baseline_lesions': total_lesions_baseline,
            'expected_remaining_lesions': sum(p['expected_remaining'] for p in recovery_projection.values()),
            'expected_recovered_lesions': overall_recovery,
            'overall_recovery_percent': (overall_recovery / max(total_lesions_baseline, 1)) * 100,
            'lesion_by_lesion': recovery_projection,
            'weeks_elapsed': weeks_since_cortisol_control,
            'interpretation': self._interpret_recovery_trajectory(
                overall_recovery, total_lesions_baseline, weeks_since_cortisol_control
            )
        }
    
    def _interpret_recovery_trajectory(self, recovered: int, baseline: int, weeks: int) -> str:
        """Interpret recovery progress"""
        
        if baseline == 0:
            return 'No lesions to recover from (good sign)'
        
        percent = (recovered / baseline) * 100
        
        if weeks < 4:
            return f'Early recovery phase ({percent:.0f}% lesions resolved; expect 60-80% total recovery by 3 months)'
        elif weeks < 12:
            return f'Active recovery ({percent:.0f}% resolved; continue monitoring)'
        elif weeks < 26:
            return f'Late recovery ({percent:.0f}% resolved; plateau approaching)'
        else:
            return f'Plateau phase ({percent:.0f}% resolved; residual damage likely permanent)'


# ============================================================================
# EXAMPLE: FULL ANALYSIS
# ============================================================================

def demo_cortisol_vascular_analysis():
    """
    Example: Patient with elevated cortisol
    How much vascular damage? Is it reversible?
    """
    
    print("\n" + "="*80)
    print("CORTISOL-INDUCED VASCULAR PATHOLOGY ANALYSIS")
    print("="*80)
    
    # Initialize agents
    dr_encoder = DRSignatureEncoder()
    cortisol_mapper = CortisolVascularMapper(dr_encoder)
    reversibility = ReversibilityPredictor()
    
    # Simulate DR signatures (normally trained on data)
    print("\n[SETUP] Training on simulated DR data...")
    
    # Create mock DR signatures
    dr_encoder.dr_signatures = {
        0: {'ma_mean': 0, 'h_mean': 0, 'cws_mean': 0, 'vb_mean': 0, 'nv_mean': 0, 'ex_mean': 0},
        1: {'ma_mean': 2.5, 'h_mean': 0.2, 'cws_mean': 0.5, 'vb_mean': 0.3, 'nv_mean': 0, 'ex_mean': 1.0},
        2: {'ma_mean': 8.5, 'h_mean': 0.8, 'cws_mean': 1.8, 'vb_mean': 1.0, 'nv_mean': 0, 'ex_mean': 3.5},
        3: {'ma_mean': 15.0, 'h_mean': 2.0, 'cws_mean': 4.0, 'vb_mean': 2.5, 'nv_mean': 0.1, 'ex_mean': 7.0},
        4: {'ma_mean': 25.0, 'h_mean': 4.5, 'cws_mean': 6.0, 'vb_mean': 4.0, 'nv_mean': 0.8, 'ex_mean': 10.0}
    }
    
    # Patient case 1: Newly elevated cortisol
    print("\n" + "-"*80)
    print("CASE 1: Recently diagnosed hypercortisolism (Cushing's syndrome)")
    print("-"*80)
    
    cortisol_level_1 = 42  # μg/dL (elevated; normal <23)
    duration_1 = 3  # months
    
    lesion_load_1, category_1 = cortisol_mapper.estimate_lesion_load_from_cortisol(
        cortisol_level_1, duration_1
    )
    
    print(f"\nCortisol level: {cortisol_level_1} μg/dL ({category_1})")
    print(f"Duration of elevation: {duration_1} months")
    print(f"\nPredicted vascular lesions:")
    for key, val in lesion_load_1.to_dict().items():
        if key != 'severity_score':
            print(f"  {key}: {val}")
    print(f"Severity score: {lesion_load_1.severity_score():.2f}/3")
    
    dr_equiv_1, explanation_1 = cortisol_mapper.map_cortisol_to_dr_equivalent(
        cortisol_level_1, {}
    )
    
    print(f"\nDR Grade Equivalent: {dr_equiv_1}")
    print(f"Interpretation: {explanation_1['dr_equivalent_interpretation']}")
    print(f"Key finding: {explanation_1['key_difference']}")
    
    # Patient case 2: Chronic, untreated
    print("\n" + "-"*80)
    print("CASE 2: Chronic untreated hypercortisolism")
    print("-"*80)
    
    cortisol_level_2 = 65  # μg/dL (severe)
    duration_2 = 18  # months
    
    lesion_load_2, category_2 = cortisol_mapper.estimate_lesion_load_from_cortisol(
        cortisol_level_2, duration_2
    )
    
    print(f"\nCortisol level: {cortisol_level_2} μg/dL ({category_2})")
    print(f"Duration of elevation: {duration_2} months")
    print(f"\nPredicted vascular lesions:")
    for key, val in lesion_load_2.to_dict().items():
        if key != 'severity_score':
            print(f"  {key}: {val}")
    print(f"Severity score: {lesion_load_2.severity_score():.2f}/3")
    
    dr_equiv_2, explanation_2 = cortisol_mapper.map_cortisol_to_dr_equivalent(
        cortisol_level_2, {}
    )
    
    print(f"\nDR Grade Equivalent: {dr_equiv_2}")
    print(f"Interpretation: {explanation_2['dr_equivalent_interpretation']}")
    
    # Reversibility: Patient 2 after metyrapone
    print("\n" + "-"*80)
    print("REVERSIBILITY: Patient 2 after cortisol control (metyrapone)")
    print("-"*80)
    
    recovery_at_3mo = reversibility.predict_recovery(lesion_load_2, weeks_since_cortisol_control=12)
    
    print(f"\nBaseline lesion load: {recovery_at_3mo['baseline_lesions']}")
    print(f"After 3 months cortisol control:")
    print(f"  Expected remaining lesions: {recovery_at_3mo['expected_remaining_lesions']}")
    print(f"  Expected recovered lesions: {recovery_at_3mo['expected_recovered_lesions']}")
    print(f"  Overall recovery: {recovery_at_3mo['overall_recovery_percent']:.0f}%")
    print(f"\nInterpretation: {recovery_at_3mo['interpretation']}")
    
    print(f"\nLesion-by-lesion recovery:")
    for lesion_type, proj in recovery_at_3mo['lesion_by_lesion'].items():
        if proj['baseline'] > 0:
            print(f"  {lesion_type}:")
            print(f"    {proj['baseline']} → {proj['expected_remaining']} (recovered {proj['expected_recovery']})")
            print(f"    Timeline: {proj['timeline_weeks']} weeks, Mechanism: {proj['mechanism']}")
    
    # Longer term: 6 months
    recovery_at_6mo = reversibility.predict_recovery(lesion_load_2, weeks_since_cortisol_control=26)
    
    print(f"\n\nLonger-term recovery (6 months):")
    print(f"  Expected recovery: {recovery_at_6mo['overall_recovery_percent']:.0f}%")
    print(f"  Interpretation: {recovery_at_6mo['interpretation']}")
    
    # Summary table
    print("\n" + "="*80)
    print("SUMMARY: How cortisol-induced vascular changes compare to DR")
    print("="*80)
    
    summary_table = pd.DataFrame([
        {
            'Case': 'Normal (control)',
            'Cortisol': '< 23 μg/dL',
            'Duration': '-',
            'Predicted Lesions': 0,
            'DR Equiv': 0,
            'CVD Risk': 'Low'
        },
        {
            'Case': 'Mild elevation',
            'Cortisol': '25-35 μg/dL',
            'Duration': '1-3 mo',
            'Predicted Lesions': 2,
            'DR Equiv': 1,
            'CVD Risk': 'Moderate'
        },
        {
            'Case': 'Moderate (Patient 1)',
            'Cortisol': f'{cortisol_level_1} μg/dL',
            'Duration': '3 mo',
            'Predicted Lesions': lesion_load_1.total_lesions(),
            'DR Equiv': dr_equiv_1,
            'CVD Risk': 'High'
        },
        {
            'Case': 'Severe (Patient 2)',
            'Cortisol': f'{cortisol_level_2} μg/dL',
            'Duration': '18 mo',
            'Predicted Lesions': lesion_load_2.total_lesions(),
            'DR Equiv': dr_equiv_2,
            'CVD Risk': 'Very High'
        }
    ])
    
    print(summary_table.to_string(index=False))
    
    print("\n" + "="*80)
    print("KEY INSIGHT")
    print("="*80)
    print("""
Even without diabetes, elevated cortisol causes measurable vascular damage.

The *pattern* of damage is similar to DR:
  • Early: Leakage (exudates), mild microaneurysms, ischemia (CWS)
  • Late: Hemorrhages, vessel dysrhythmia, widespread lesions

The *mechanism* is different (endothelial dysfunction, not hyperglycemia),
but the vascular phenotype is comparable.

Clinical implication: A patient with cortisol=50 μg/dL but no diabetes
shows vascular changes *equivalent to DR grade 2*, meaning HIGH CVD RISK.

Standard CVD risk calculators miss this entirely — they see "no diabetes,
LDL normal" and miss the cortisol-driven endothelial damage.

The retinal endothelial test (DVA with flicker response) would detect this.
    """)


if __name__ == '__main__':
    demo_cortisol_vascular_analysis()
