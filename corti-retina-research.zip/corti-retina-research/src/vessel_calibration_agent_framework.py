#!/usr/bin/env python3
"""
Vessel Calibration Agent Framework
Uses extracted Kaggle retinal data to build calibration pipelines
Maps to your hypercortisolism study model
"""

import json
import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Dict, List, Tuple
import pickle

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class RetinalImage:
    """Represents a single retinal image with extracted metrics"""
    image_id: str
    dataset: str
    dr_grade: int
    vessel_density: float
    vessel_count: int
    mean_vessel_width: float
    image_entropy: float
    cortisol_level: float = None  # Will be added for hypercortisolism data
    cvd_risk: float = None  # Will be predicted

@dataclass
class CalibrationResult:
    """Result of calibration operation"""
    parameter_name: str
    baseline_value: float
    corrected_value: float
    correction_factor: float
    confidence: float

# ============================================================================
# AGENT 1: PRESSURE CALIBRATION AGENT
# ============================================================================

class PressureCalibrationAgent:
    """
    Calibrates vessel measurements for intraocular pressure (IOP)
    and systemic blood pressure effects
    
    In retinal imaging:
    - Higher IOP compresses vessels, reducing apparent diameter
    - Higher BP increases vessel distension
    """
    
    def __init__(self, reference_iop=15, reference_sbp=120):
        self.reference_iop = reference_iop  # mmHg (normal)
        self.reference_sbp = reference_sbp  # mmHg (normal)
        self.calibration_model = None
    
    def train_on_data(self, data_df: pd.DataFrame):
        """
        Train pressure correction model
        Assumes data includes: vessel_density, iop, systolic_bp columns
        """
        print("[AGENT 1] Training Pressure Calibration...")
        
        # For demonstration with Kaggle data (which lacks IOP/BP):
        # Model the relationship between vessel metrics and DR grade as proxy
        # In real study, use actual pressure measurements
        
        self.vessel_stats = {
            grade: data_df[data_df['dr_grade'] == grade][
                ['vessel_density', 'vessel_count', 'mean_vessel_width']
            ].describe().to_dict()
            for grade in sorted(data_df['dr_grade'].unique())
        }
        
        print(f"  ✓ Calibration model trained on {len(data_df)} images")
        return self
    
    def normalize_vessel_diameter(self, vessel_width: float, measured_iop: float, 
                                 measured_sbp: float) -> Tuple[float, float]:
        """
        Normalize vessel width to standard pressure conditions
        
        Returns:
            (corrected_width, correction_factor)
        """
        # IOP effect: each 5 mmHg difference ≈ 3% vessel diameter change
        iop_correction = 1 + (measured_iop - self.reference_iop) * 0.006
        
        # SBP effect: higher BP → more vessel distension
        sbp_correction = 1 + (measured_sbp - self.reference_sbp) * 0.002
        
        corrected_width = vessel_width / (iop_correction * sbp_correction)
        correction_factor = iop_correction * sbp_correction
        
        return corrected_width, correction_factor
    
    def calibrate(self, image: RetinalImage, measured_iop: float = 15, 
                 measured_sbp: float = 120) -> CalibrationResult:
        """Apply pressure calibration to an image"""
        
        corrected_width, cf = self.normalize_vessel_diameter(
            image.mean_vessel_width, measured_iop, measured_sbp
        )
        
        return CalibrationResult(
            parameter_name='vessel_width_pressure_corrected',
            baseline_value=image.mean_vessel_width,
            corrected_value=corrected_width,
            correction_factor=cf,
            confidence=0.85  # Typical for pressure correction
        )


# ============================================================================
# AGENT 2: MOTION ARTIFACT CORRECTION AGENT
# ============================================================================

class MotionArtifactAgent:
    """
    Detects and corrects image quality issues from eye movement
    Uses image entropy and vessel detection quality
    """
    
    def __init__(self, quality_threshold=0.6):
        self.quality_threshold = quality_threshold
        self.reference_entropy = 5.5  # Typical fundus image entropy
    
    def assess_image_quality(self, image: RetinalImage) -> Dict:
        """Assess image quality based on entropy and vessel detection"""
        
        # Entropy drift from normal
        entropy_score = 1 - abs(image.image_entropy - self.reference_entropy) / 3
        entropy_score = max(0, min(1, entropy_score))  # Clamp 0-1
        
        # Vessel detection quality (vessel_count correlates with quality)
        # Low vessel count might indicate motion blur or poor contrast
        vessel_quality = min(1.0, image.vessel_count / 500)  # 500 = good detection
        
        # Combined quality
        overall_quality = (entropy_score + vessel_quality) / 2
        
        return {
            'overall_quality': overall_quality,
            'entropy_score': entropy_score,
            'vessel_detection_quality': vessel_quality,
            'is_valid': overall_quality > self.quality_threshold
        }
    
    def correct_for_motion(self, image: RetinalImage, quality_metrics: Dict) -> RetinalImage:
        """
        Correct vessel measurements for motion artifacts
        Lower quality → more uncertainty
        """
        
        quality = quality_metrics['overall_quality']
        
        # Apply confidence-weighted adjustment
        # Poor quality images get dampened metrics (conservative estimate)
        adjustment_factor = 0.5 + 0.5 * quality  # Range: 0.5-1.0
        
        corrected_image = RetinalImage(
            image_id=image.image_id,
            dataset=image.dataset,
            dr_grade=image.dr_grade,
            vessel_density=image.vessel_density * adjustment_factor,
            vessel_count=image.vessel_count,  # Not adjusted (count is discrete)
            mean_vessel_width=image.mean_vessel_width * adjustment_factor,
            image_entropy=image.image_entropy,
            cortisol_level=image.cortisol_level,
            cvd_risk=image.cvd_risk
        )
        
        return corrected_image


# ============================================================================
# AGENT 3: FLICKER STIMULUS CALIBRATION AGENT
# ============================================================================

class FlickerStimulusAgent:
    """
    Calibrates flicker-light response (NO-dependent vasodilation)
    Maps vessel response patterns to cortisol-induced endothelial dysfunction
    
    Key: Reduced flicker response = impaired NO bioavailability
    """
    
    def __init__(self):
        # In real DVA data, this would be actual dilation percentages
        # Using vessel_density as proxy for baseline tone
        self.flicker_response_baseline = 5.0  # % dilation in healthy subjects
        self.impairment_threshold = 2.0  # % dilation = dysfunction
    
    def estimate_flicker_response(self, image: RetinalImage, dr_grade: int = None) -> Dict:
        """
        Estimate NO-dependent vasodilation from vessel metrics
        
        Reasoning:
        - Healthy vessels: high density, consistent width → good flicker response
        - Damaged vessels: reduced density, irregular width → poor flicker response
        """
        
        # Use DR grade as proxy for vascular damage if provided
        if dr_grade is None:
            dr_grade = image.dr_grade
        
        # Estimate baseline NO availability (inverse of DR damage)
        # DR Grade 0 (normal) → full NO response
        # DR Grade 4 (proliferative) → severely impaired
        
        no_availability = 1.0 - (dr_grade * 0.25)  # 100% → 0% across grades
        
        # Expected flicker response
        estimated_response = self.flicker_response_baseline * no_availability
        
        # Vessel width consistency (CV = coefficient of variation)
        # Used as proxy for vessel reactivity
        width_consistency = image.mean_vessel_width  # Simplified
        
        return {
            'estimated_flicker_response_percent': estimated_response,
            'no_bioavailability': no_availability,
            'is_impaired': estimated_response < self.impairment_threshold,
            'response_quality': 'Normal' if estimated_response >= self.flicker_response_baseline * 0.8 
                               else 'Impaired'
        }
    
    def calibrate_for_consistency(self, measurements_series: List[float]) -> Dict:
        """
        Calibrate flicker response measurements across repeated measurements
        (simulating 3-month and 6-month timepoints in metyrapone study)
        """
        
        measurements = np.array(measurements_series)
        
        return {
            'mean_response': np.mean(measurements),
            'std_dev': np.std(measurements),
            'cv': np.std(measurements) / np.mean(measurements) if np.mean(measurements) > 0 else 0,
            'trend': 'improving' if measurements[-1] > measurements[0] else 'declining',
            'consistency_score': 1 - min(1.0, np.std(measurements) / 3.0)  # Max 3% acceptable SD
        }


# ============================================================================
# AGENT 4: CURVE FITTING AGENT
# ============================================================================

class CurveFittingAgent:
    """
    Models full dilation-relaxation curve
    Rather than single-point measurements, captures dynamic response
    """
    
    def __init__(self):
        self.baseline_vessel_width = 1.0  # Normalized
        self.peak_dilation_time = 60  # seconds (typical)
    
    def fit_dilation_curve(self, image: RetinalImage, time_series_data: List[float] = None) -> Dict:
        """
        Fit vessel diameter response curve
        
        In real DVA:
        - Measure vessel diameter at: baseline, 1s, 2s, ..., 300s (5 min)
        - Fit curve to extract: peak dilation, time-to-peak, recovery rate
        """
        
        if time_series_data is None:
            # Simulate curve using vessel width as peak dilation estimate
            time_series_data = self._simulate_dilation_curve(image)
        
        time_points = np.linspace(0, 300, len(time_series_data))
        
        # Extract curve characteristics
        peak_dilation = np.max(time_series_data)
        time_to_peak = time_points[np.argmax(time_series_data)]
        
        # Recovery (return toward baseline by end of measurement)
        recovery_percent = (time_series_data[0] - time_series_data[-1]) / time_series_data[0] * 100 if time_series_data[0] > 0 else 0
        
        return {
            'peak_dilation_percent': float(peak_dilation),
            'time_to_peak_seconds': float(time_to_peak),
            'recovery_percent': float(recovery_percent),
            'curve_shape': self._classify_curve(time_series_data),
            'is_abnormal': peak_dilation < 3.0  # < 3% = impaired
        }
    
    def _simulate_dilation_curve(self, image: RetinalImage) -> List[float]:
        """Simulate dilation curve from vessel metrics"""
        
        # Use vessel density as proxy for vasodilatory capacity
        max_dilation = image.vessel_density * 10  # Scaled to % dilation
        
        # Gaussian-like response curve
        t = np.linspace(0, 300, 50)
        curve = max_dilation * np.exp(-(t - 60)**2 / (2 * 40**2))
        
        return curve.tolist()
    
    def _classify_curve(self, curve: List[float]) -> str:
        """Classify curve shape"""
        
        peak_idx = np.argmax(curve)
        early_response = np.mean(curve[:peak_idx//2])
        late_response = np.mean(curve[peak_idx:])
        
        if late_response > early_response:
            return 'delayed'
        elif np.max(curve) < 2.0:
            return 'blunted'
        else:
            return 'normal'


# ============================================================================
# AGENT 5: NORMALIZATION & PREDICTION AGENT
# ============================================================================

class NormalizationPredictionAgent:
    """
    Synthesizes all calibrations and generates:
    1. Retinal "age" score (vascular aging)
    2. CVD risk prediction
    3. Cortisol-vascular coupling estimate
    """
    
    def __init__(self, reference_data: pd.DataFrame = None):
        self.reference_data = reference_data  # age/sex-matched population data
        self.age_reference = None  # Will store age-specific norms
    
    def train_on_reference(self, data_df: pd.DataFrame):
        """Train normalization against reference population"""
        
        print("[AGENT 5] Training Normalization on Reference Data...")
        
        # Group by age and sex (if available) to create reference tables
        self.age_reference = {}
        
        for dr_grade in sorted(data_df['dr_grade'].unique()):
            subset = data_df[data_df['dr_grade'] == dr_grade]
            self.age_reference[dr_grade] = {
                'vessel_density_mean': subset['vessel_density'].mean(),
                'vessel_density_std': subset['vessel_density'].std(),
                'vessel_count_mean': subset['vessel_count'].mean(),
                'vessel_count_std': subset['vessel_count'].std(),
                'mean_width_mean': subset['mean_vessel_width'].mean(),
                'mean_width_std': subset['mean_vessel_width'].std(),
            }
        
        print(f"  ✓ Normalized against {len(data_df)} reference images")
        return self
    
    def calculate_retinal_age(self, image: RetinalImage) -> Dict:
        """
        Calculate vascular "retinal age" - how old does the vasculature look?
        
        Compares vessel metrics to age/sex-matched population
        Output: If patient is 45 but retinal age = 65, vascular aging by 20 years
        """
        
        if self.age_reference is None:
            print("⚠ Reference data not loaded. Train first.")
            return {}
        
        # Simplified: use closest DR grade as reference
        ref_grade = image.dr_grade
        ref = self.age_reference.get(ref_grade, self.age_reference[0])
        
        # Z-score for vessel density
        z_density = (image.vessel_density - ref['vessel_density_mean']) / (ref['vessel_density_std'] + 1e-6)
        
        # Z-score for vessel count
        z_count = (image.vessel_count - ref['vessel_count_mean']) / (ref['vessel_count_std'] + 1e-6)
        
        # Combined z-score (negative = older vascular age)
        combined_z = (z_density + z_count) / 2
        
        # Rough estimate: each SD = ~3 years vascular aging
        vascular_age_offset = -combined_z * 3
        
        return {
            'vascular_age_offset_years': float(vascular_age_offset),
            'vessel_density_zscore': float(z_density),
            'vessel_count_zscore': float(z_count),
            'interpretation': self._interpret_vascular_age(vascular_age_offset)
        }
    
    def predict_cvd_risk(self, image: RetinalImage, vascular_age: Dict, 
                        cortisol_level: float = None) -> Dict:
        """
        Predict CVD risk from vascular metrics
        
        Inputs:
        - Vessel metrics (normalized)
        - Vascular age offset
        - Cortisol level (optional, if from hypercortisolism study)
        """
        
        # Base risk from DR grade
        dr_risk_score = (image.dr_grade / 4.0) * 50  # 0-50 points from DR
        
        # Vascular age contribution
        vascular_age_offset = vascular_age.get('vascular_age_offset_years', 0)
        age_risk = max(0, vascular_age_offset * 2)  # 2 points per year of aging
        
        # Vessel width regularity (lower = more irregular = higher risk)
        width_regularity = 100 / (image.mean_vessel_width + 1)  # Inverted proxy
        width_risk = (1 - min(1, width_regularity / 10)) * 30  # 0-30 points
        
        # Cortisol-specific risk (if provided)
        cortisol_risk = 0
        if cortisol_level is not None:
            # Cortisol >20 μg/dL is elevated; CVD risk increases non-linearly
            if cortisol_level > 20:
                cortisol_risk = (cortisol_level - 20) * 1.5  # 1.5 points per μg/dL above 20
        
        # Total risk (0-100 scale)
        total_risk = min(100, dr_risk_score + age_risk + width_risk + cortisol_risk)
        
        # Risk category
        if total_risk < 20:
            risk_category = 'Low'
        elif total_risk < 40:
            risk_category = 'Moderate'
        elif total_risk < 60:
            risk_category = 'High'
        else:
            risk_category = 'Very High'
        
        return {
            'cvd_risk_score': float(total_risk),
            'risk_category': risk_category,
            'component_breakdown': {
                'dr_contribution': float(dr_risk_score),
                'vascular_aging_contribution': float(age_risk),
                'vessel_irregularity_contribution': float(width_risk),
                'cortisol_contribution': float(cortisol_risk)
            },
            'requires_intervention': risk_category in ['High', 'Very High']
        }
    
    def _interpret_vascular_age(self, offset: float) -> str:
        """Interpret vascular age offset"""
        
        if abs(offset) < 2:
            return 'Normal for age'
        elif offset < -5:
            return 'Significantly younger than chronological age (rare)'
        elif offset > 5 and offset <= 10:
            return 'Moderately accelerated aging'
        elif offset > 10 and offset <= 20:
            return 'Significantly accelerated aging'
        else:
            return 'Severely accelerated aging (very high CVD risk)'


# ============================================================================
# ORCHESTRATOR: COMPLETE AGENT PIPELINE
# ============================================================================

class VesselCalibrationPipeline:
    """
    Orchestrates all agents to process an image end-to-end
    """
    
    def __init__(self):
        self.pressure_agent = PressureCalibrationAgent()
        self.motion_agent = MotionArtifactAgent()
        self.flicker_agent = FlickerStimulusAgent()
        self.curve_agent = CurveFittingAgent()
        self.prediction_agent = NormalizationPredictionAgent()
    
    def train_all_agents(self, training_data: pd.DataFrame):
        """Train all agents on reference dataset"""
        
        print("\n" + "="*80)
        print("TRAINING VESSEL CALIBRATION AGENTS")
        print("="*80)
        
        self.pressure_agent.train_on_data(training_data)
        self.prediction_agent.train_on_reference(training_data)
        
        print("\n✓ All agents trained and ready")
    
    def process_image(self, image: RetinalImage, measured_iop: float = 15,
                     measured_sbp: float = 120, cortisol_level: float = None) -> Dict:
        """Process single image through full pipeline"""
        
        print(f"\nProcessing: {image.image_id}")
        
        # 1. Assess image quality
        quality_metrics = self.motion_agent.assess_image_quality(image)
        print(f"  ✓ Quality: {quality_metrics['overall_quality']:.2%}")
        
        if not quality_metrics['is_valid']:
            print(f"    ⚠ Image quality below threshold, applying corrections")
            image = self.motion_agent.correct_for_motion(image, quality_metrics)
        
        # 2. Pressure calibration
        pressure_result = self.pressure_agent.calibrate(image, measured_iop, measured_sbp)
        print(f"  ✓ Pressure calibration: {pressure_result.correction_factor:.3f}x")
        
        # 3. Flicker response estimation
        flicker_result = self.flicker_agent.estimate_flicker_response(image)
        print(f"  ✓ Flicker response: {flicker_result['estimated_flicker_response_percent']:.2f}%")
        
        # 4. Curve fitting
        curve_result = self.curve_agent.fit_dilation_curve(image)
        print(f"  ✓ Curve fitting: Peak dilation {curve_result['peak_dilation_percent']:.2f}%")
        
        # 5. Normalization & prediction
        vascular_age = self.prediction_agent.calculate_retinal_age(image)
        print(f"  ✓ Vascular age: {vascular_age.get('vascular_age_offset_years', 0):.1f} years offset")
        
        cvd_risk = self.prediction_agent.predict_cvd_risk(image, vascular_age, cortisol_level)
        print(f"  ✓ CVD Risk: {cvd_risk['risk_category']} ({cvd_risk['cvd_risk_score']:.0f}/100)")
        
        # Aggregate results
        return {
            'image_id': image.image_id,
            'quality_metrics': quality_metrics,
            'pressure_calibration': pressure_result.__dict__,
            'flicker_response': flicker_result,
            'curve_fitting': curve_result,
            'vascular_age': vascular_age,
            'cvd_risk_prediction': cvd_risk
        }


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

def demo_pipeline():
    """Demonstrate the agent pipeline"""
    
    print("\n" + "="*80)
    print("VESSEL CALIBRATION AGENT DEMO")
    print("="*80)
    
    # Load agent data created by extraction script
    try:
        with open('agent_vessel_data.json', 'r') as f:
            agent_data = json.load(f)
    except FileNotFoundError:
        print("⚠ agent_vessel_data.json not found. Run extraction script first.")
        print("  Command: python download_and_extract_retinal_data.py")
        return
    
    # Convert to DataFrame for training
    images_data = agent_data['images'][:100]  # Use first 100 for demo
    df = pd.DataFrame([
        {
            'image_id': img['image_id'],
            'dataset': img['dataset'],
            'dr_grade': img['dr_grade'],
            'vessel_density': 0.15 + np.random.normal(0, 0.05),
            'vessel_count': 200 + np.random.normal(0, 30),
            'mean_vessel_width': 15 + np.random.normal(0, 2)
        }
        for img in images_data
    ])
    
    # Initialize pipeline
    pipeline = VesselCalibrationPipeline()
    pipeline.train_all_agents(df)
    
    # Process sample image
    sample_image = RetinalImage(
        image_id='sample_001',
        dataset='EyePACS',
        dr_grade=2,  # Moderate DR
        vessel_density=0.18,
        vessel_count=220,
        mean_vessel_width=14.5,
        image_entropy=5.2,
        cortisol_level=25.0  # Elevated cortisol (μg/dL)
    )
    
    result = pipeline.process_image(sample_image, measured_iop=16, measured_sbp=135)
    
    print("\n" + "="*80)
    print("FINAL REPORT")
    print("="*80)
    print(json.dumps(result, indent=2, default=str))


if __name__ == '__main__':
    demo_pipeline()
