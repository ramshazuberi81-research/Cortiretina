#!/usr/bin/env python3
"""
Integration: Frangi Features → Cortisol Vascular Pathology Prediction

Pipeline:
  Retinal Image
    ↓
  Frangi Filter (extract vessel metrics)
    ↓
  Lesion Prediction (map metrics to DR-like lesions)
    ↓
  Cortisol Status Classification
    ↓
  CVD Risk Assessment

This bridges the gap between image analysis and clinical interpretation.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Dict, Tuple
import json

# Assume we have these from previous modules
# from frangi_feature_extractor import FrangiFeatureExtractor
# from cortisol_vascular_pathology_mapper import CortisolVascularMapper


@dataclass
class VesselMetrics:
    """Parsed Frangi-extracted vessel metrics"""
    
    # Density
    vessel_density: float
    image_coverage_percent: float
    
    # Count
    vessel_count: int
    mean_vessel_size: float
    
    # Caliber
    mean_vessel_width: float
    vessel_width_std: float
    width_regularity: float  # 0-1, higher = more regular
    
    # Tortuosity
    mean_tortuosity: float
    percent_tortuous: float
    
    # Fractal
    fractal_dimension: float
    
    # AVR
    avr: float
    
    # Derived metrics (computed from above)
    vessel_quality_score: float = None
    vascular_damage_index: float = None
    
    def compute_derived_metrics(self):
        """Compute composite metrics from individual measurements"""
        
        # Vessel Quality Score (0-1, higher = healthier)
        # Combines: good density, regular width, low tortuosity, normal fractal
        
        density_score = min(1.0, self.vessel_density / 0.25)  # 25% = excellent
        regularity_score = self.width_regularity
        tortuosity_score = max(0, 1 - (self.mean_tortuosity - 1.0) / 0.5)  # 1.0-1.5 normal
        fractal_score = 1 - abs(self.fractal_dimension - 1.5) / 0.5  # 1.4-1.6 normal
        
        self.vessel_quality_score = (density_score + regularity_score + 
                                     tortuosity_score + fractal_score) / 4.0
        
        # Vascular Damage Index (0-1, higher = more damage)
        # Inverse of quality score
        self.vascular_damage_index = 1 - self.vessel_quality_score
        
        return self


# ============================================================================
# FEATURE MAPPING: Frangi → Lesions
# ============================================================================

class FrangiToLesionMapper:
    """
    Map Frangi-extracted vessel metrics to predicted lesion counts
    
    Key mappings:
    - Low density → microaneurysms, exudates
    - High tortuosity → venous beading
    - Irregular width → vessel damage
    - Low fractal → poor perfusion (CWS)
    """
    
    def __init__(self):
        """Initialize with lesion prediction rules"""
        
        # Empirically-derived mappings (based on DR studies)
        self.lesion_thresholds = {
            'vessel_density': {
                'exudates': 0.12,  # Low density = leakage
                'microaneurysms': 0.10,
            },
            'mean_tortuosity': {
                'venous_beading': 1.15,  # >1.15 = beading
            },
            'width_regularity': {
                'microaneurysms': 0.5,  # Low regularity = instability
            },
            'fractal_dimension': {
                'cotton_wool_spots': 1.3,  # Low FD = poor branching = ischemia
            }
        }
    
    def predict_lesion_load(self, vessel_metrics: VesselMetrics) -> Dict:
        """
        Predict lesion load from vessel metrics
        
        Returns dictionary with predicted counts of each lesion type
        """
        
        predictions = {
            'microaneurysms': 0,
            'hemorrhages': 0,
            'cotton_wool_spots': 0,
            'venous_beading': 0,
            'neovascularization': 0,
            'exudates': 0
        }
        
        # Rule 1: Low density → exudates (BBB/BRB breakdown)
        if vessel_metrics.vessel_density < self.lesion_thresholds['vessel_density']['exudates']:
            density_deficit = (self.lesion_thresholds['vessel_density']['exudates'] - 
                             vessel_metrics.vessel_density)
            predictions['exudates'] = int(density_deficit * 30)  # Scale to count
        
        # Rule 2: Low density AND low regularity → microaneurysms
        if (vessel_metrics.vessel_density < self.lesion_thresholds['vessel_density']['microaneurysms'] and
            vessel_metrics.width_regularity < self.lesion_thresholds['width_regularity']['microaneurysms']):
            
            metric = (1 - vessel_metrics.width_regularity) * \
                    (1 - vessel_metrics.vessel_density / 0.15)
            predictions['microaneurysms'] = int(metric * 20)
        
        # Rule 3: High tortuosity → venous beading
        if vessel_metrics.mean_tortuosity > self.lesion_thresholds['mean_tortuosity']['venous_beading']:
            tortuosity_excess = vessel_metrics.mean_tortuosity - \
                               self.lesion_thresholds['mean_tortuosity']['venous_beading']
            predictions['venous_beading'] = int(tortuosity_excess * 10)
        
        # Rule 4: Low fractal dimension → cotton wool spots (ischemia)
        if vessel_metrics.fractal_dimension < self.lesion_thresholds['fractal_dimension']['cotton_wool_spots']:
            fractal_deficit = (self.lesion_thresholds['fractal_dimension']['cotton_wool_spots'] - 
                             vessel_metrics.fractal_dimension)
            predictions['cotton_wool_spots'] = int(fractal_deficit * 15)
        
        # Rule 5: Multiple damage markers → hemorrhages
        damage_count = sum([
            vessel_metrics.vessel_density < 0.12,
            vessel_metrics.mean_tortuosity > 1.15,
            vessel_metrics.width_regularity < 0.5,
            vessel_metrics.fractal_dimension < 1.3
        ])
        
        if damage_count >= 3:
            predictions['hemorrhages'] = 1
        
        return predictions


# ============================================================================
# CORTISOL STATUS CLASSIFIER
# ============================================================================

class CortisolStatusClassifier:
    """
    Map vascular metrics + lesion load + cortisol level → cortisol status
    """
    
    def __init__(self):
        self.cortisol_cutoffs = {
            'normal': (0, 23),
            'mild': (23, 35),
            'moderate': (35, 50),
            'severe': (50, float('inf'))
        }
    
    def classify_cortisol_status(self, cortisol_level: float) -> Tuple[str, str]:
        """Classify cortisol level and explain"""
        
        interpretations = {
            'normal': 'Normal cortisol; no endothelial stress expected',
            'mild': 'Mild elevation; early endothelial dysfunction possible',
            'moderate': 'Significant elevation; definite vascular changes expected',
            'severe': 'Severe hypercortisolism; extensive vascular damage expected'
        }
        
        for status, (low, high) in self.cortisol_cutoffs.items():
            if low <= cortisol_level < high:
                return status, interpretations[status]
        
        return 'unknown', 'Cortisol status unclear'
    
    def match_phenotype_to_cortisol(self, 
                                   vessel_metrics: VesselMetrics,
                                   lesion_predictions: Dict,
                                   cortisol_level: float) -> Dict:
        """
        Check if observed vascular phenotype matches expected cortisol status
        """
        
        status, status_explanation = self.classify_cortisol_status(cortisol_level)
        
        # Expected metrics by cortisol status
        expected_metrics = {
            'normal': {
                'vessel_quality_score_min': 0.75,
                'vascular_damage_index_max': 0.25,
                'total_lesions_max': 2
            },
            'mild': {
                'vessel_quality_score_min': 0.60,
                'vascular_damage_index_max': 0.40,
                'total_lesions_max': 5
            },
            'moderate': {
                'vessel_quality_score_min': 0.40,
                'vascular_damage_index_max': 0.60,
                'total_lesions_max': 12
            },
            'severe': {
                'vessel_quality_score_min': 0.20,
                'vascular_damage_index_max': 0.80,
                'total_lesions_max': 25
            }
        }
        
        expected = expected_metrics.get(status, expected_metrics['normal'])
        total_lesions = sum(lesion_predictions.values())
        
        # Check consistency
        is_consistent = (
            vessel_metrics.vessel_quality_score >= expected['vessel_quality_score_min'] * 0.8 and
            vessel_metrics.vascular_damage_index <= expected['vascular_damage_index_max'] * 1.2 and
            total_lesions <= expected['total_lesions_max'] * 1.3
        )
        
        consistency_score = 1.0
        if not is_consistent:
            # Calculate how far off observed vs expected
            quality_diff = abs(vessel_metrics.vessel_quality_score - expected['vessel_quality_score_min']) / expected['vessel_quality_score_min']
            damage_diff = abs(vessel_metrics.vascular_damage_index - expected['vascular_damage_index_max']) / expected['vascular_damage_index_max']
            lesion_diff = abs(total_lesions - expected['total_lesions_max']) / expected['total_lesions_max']
            
            consistency_score = 1 - (quality_diff + damage_diff + lesion_diff) / 3
            consistency_score = max(0, min(1, consistency_score))
        
        return {
            'cortisol_status': status,
            'cortisol_explanation': status_explanation,
            'expected_metrics': expected,
            'observed_lesion_count': total_lesions,
            'phenotype_cortisol_match': is_consistent,
            'match_consistency_score': consistency_score,
            'interpretation': self._interpret_match(is_consistent, cortisol_level, total_lesions)
        }
    
    def _interpret_match(self, is_consistent: bool, cortisol_level: float, 
                        lesion_count: int) -> str:
        """Generate clinical interpretation"""
        
        if is_consistent:
            return f"Vascular phenotype matches cortisol level ({cortisol_level:.1f} μg/dL). Findings consistent with hypercortisolism."
        elif cortisol_level < 23:
            return f"Cortisol normal but vascular damage observed. Other pathology likely (not cortisol-related). Recommend diabetes/HTN evaluation."
        elif lesion_count > 15:
            return f"Cortisol moderately elevated but extensive vascular damage. Possible chronic exposure or other concurrent pathology."
        else:
            return f"Mild vascular changes despite elevated cortisol. Consider treatment efficacy or early disease stage."


# ============================================================================
# CVD RISK ASSESSMENT
# ============================================================================

class CortisolCVDRiskCalculator:
    """
    Estimate CVD risk based on:
    1. Vascular metrics (from Frangi)
    2. Lesion load (from mapping)
    3. Cortisol level
    4. Duration of exposure
    """
    
    def calculate_risk(self, 
                      vessel_metrics: VesselMetrics,
                      lesion_predictions: Dict,
                      cortisol_level: float,
                      cortisol_duration_months: int = 1) -> Dict:
        """
        Calculate CVD risk score (0-100 scale)
        """
        
        # Component 1: Vascular damage index (0-30 points)
        vascular_damage_score = vessel_metrics.vascular_damage_index * 30
        
        # Component 2: Lesion burden (0-35 points)
        total_lesions = sum(lesion_predictions.values())
        lesion_score = min(35, total_lesions * 2)  # Escalates with lesion count
        
        # Component 3: Cortisol level (0-25 points)
        if cortisol_level < 25:
            cortisol_score = 0
        elif cortisol_level < 35:
            cortisol_score = (cortisol_level - 25) * 1.25  # 0-12.5 points
        elif cortisol_level < 50:
            cortisol_score = 12.5 + (cortisol_level - 35) * 0.83  # 12.5-25 points
        else:
            cortisol_score = 25
        
        # Component 4: Duration effect (accelerates risk)
        duration_multiplier = 1 + (min(cortisol_duration_months, 24) / 24) * 0.25
        
        # Total risk score
        total_risk = (vascular_damage_score + lesion_score + cortisol_score) * duration_multiplier
        total_risk = min(100, total_risk)
        
        # Risk category
        if total_risk < 20:
            risk_category = 'Low'
            recommendation = 'Standard monitoring'
        elif total_risk < 40:
            risk_category = 'Moderate'
            recommendation = 'Regular retinal screening, BP monitoring'
        elif total_risk < 60:
            risk_category = 'High'
            recommendation = 'Intensive cortisol control (consider metyrapone), cardiology referral'
        else:
            risk_category = 'Very High'
            recommendation = 'Urgent cortisol management, comprehensive CVD workup'
        
        return {
            'cvd_risk_score': float(total_risk),
            'risk_category': risk_category,
            'recommendation': recommendation,
            'component_breakdown': {
                'vascular_damage_component': float(vascular_damage_score),
                'lesion_burden_component': float(lesion_score),
                'cortisol_component': float(cortisol_score),
                'duration_multiplier': float(duration_multiplier)
            }
        }


# ============================================================================
# COMPLETE PIPELINE
# ============================================================================

class CortisolVascularAnalysisPipeline:
    """
    End-to-end pipeline: Frangi features → Cortisol classification → CVD risk
    """
    
    def __init__(self):
        self.lesion_mapper = FrangiToLesionMapper()
        self.cortisol_classifier = CortisolStatusClassifier()
        self.risk_calculator = CortisolCVDRiskCalculator()
    
    def analyze_patient(self, 
                       vessel_metrics_dict: Dict,
                       cortisol_level: float,
                       cortisol_duration_months: int = 1) -> Dict:
        """
        Complete patient analysis from Frangi features to risk assessment
        """
        
        # Step 1: Parse and validate metrics
        vessel_metrics = VesselMetrics(**vessel_metrics_dict)
        vessel_metrics.compute_derived_metrics()
        
        print("\n" + "="*80)
        print("CORTISOL-VASCULAR ANALYSIS")
        print("="*80)
        
        print("\n[STEP 1] Vessel Metrics Summary")
        print(f"  Vessel density: {vessel_metrics.vessel_density:.4f}")
        print(f"  Vessel quality score: {vessel_metrics.vessel_quality_score:.3f}")
        print(f"  Vascular damage index: {vessel_metrics.vascular_damage_index:.3f}")
        
        # Step 2: Map to lesion predictions
        lesion_predictions = self.lesion_mapper.predict_lesion_load(vessel_metrics)
        
        print("\n[STEP 2] Predicted Vascular Lesions")
        for lesion_type, count in lesion_predictions.items():
            if count > 0:
                print(f"  {lesion_type}: {count}")
        
        # Step 3: Cortisol status classification
        cortisol_assessment = self.cortisol_classifier.match_phenotype_to_cortisol(
            vessel_metrics, lesion_predictions, cortisol_level
        )
        
        print("\n[STEP 3] Cortisol Status Classification")
        print(f"  Cortisol level: {cortisol_level:.1f} μg/dL")
        print(f"  Status: {cortisol_assessment['cortisol_status']}")
        print(f"  Phenotype-cortisol match: {cortisol_assessment['phenotype_cortisol_match']}")
        print(f"  Consistency score: {cortisol_assessment['match_consistency_score']:.2%}")
        
        # Step 4: CVD risk calculation
        risk_assessment = self.risk_calculator.calculate_risk(
            vessel_metrics, lesion_predictions, cortisol_level, cortisol_duration_months
        )
        
        print("\n[STEP 4] CVD Risk Assessment")
        print(f"  Risk score: {risk_assessment['cvd_risk_score']:.0f}/100")
        print(f"  Risk category: {risk_assessment['risk_category']}")
        print(f"  Recommendation: {risk_assessment['recommendation']}")
        
        # Aggregate results
        return {
            'vessel_metrics': vessel_metrics.__dict__,
            'lesion_predictions': lesion_predictions,
            'cortisol_assessment': cortisol_assessment,
            'risk_assessment': risk_assessment,
            'summary': self._generate_summary(vessel_metrics, cortisol_assessment, risk_assessment)
        }
    
    def _generate_summary(self, vessel_metrics, cortisol_assessment, risk_assessment) -> str:
        """Generate clinical summary"""
        
        summary = f"""
CLINICAL SUMMARY
================

Vascular Status: {vessel_metrics.vessel_quality_score:.1%} quality (lower = more damage)

Cortisol Interpretation: {cortisol_assessment['interpretation']}

CVD Risk: {risk_assessment['risk_category']} ({risk_assessment['cvd_risk_score']:.0f}/100)
  → {risk_assessment['recommendation']}

Key Finding: Without diabetes, this patient shows {
    'mild' if risk_assessment['cvd_risk_score'] < 30 else
    'moderate' if risk_assessment['cvd_risk_score'] < 50 else
    'significant'
} cortisol-induced vascular damage.

Next Steps:
  1. Repeat cortisol level (confirm elevation)
  2. Identify cortisol source (Cushing's syndrome workup)
  3. Start cortisol-lowering therapy (metyrapone if ectopic source)
  4. Repeat retinal imaging at 3 and 6 months to assess reversibility
  5. Comprehensive CVD evaluation (ECG, echocardiogram, lipids)
        """
        
        return summary


# ============================================================================
# DEMO
# ============================================================================

def demo_pipeline():
    """Demonstrate complete pipeline"""
    
    pipeline = CortisolVascularAnalysisPipeline()
    
    # Example: Patient with moderate hypercortisolism
    example_vessel_metrics = {
        'vessel_density': 0.12,  # Below normal
        'image_coverage_percent': 12.0,
        'vessel_count': 150,  # Reduced
        'mean_vessel_size': 45,
        'mean_vessel_width': 11.5,  # Narrower than normal (12-18)
        'vessel_width_std': 4.2,
        'width_regularity': 0.55,  # Irregular
        'mean_tortuosity': 1.22,  # Somewhat tortuous
        'percent_tortuous': 35,
        'fractal_dimension': 1.32,  # Below normal (1.4-1.6)
        'avr': 0.75
    }
    
    cortisol_level = 45  # μg/dL (elevated)
    duration = 6  # months
    
    results = pipeline.analyze_patient(
        example_vessel_metrics,
        cortisol_level,
        duration
    )
    
    print(results['summary'])
    
    # Save results
    import json
    with open('/tmp/cortisol_vascular_analysis.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print("\n✓ Full results saved to /tmp/cortisol_vascular_analysis.json")


if __name__ == '__main__':
    demo_pipeline()
