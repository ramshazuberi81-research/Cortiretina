# Complete Guide to Extracting Features from Frangi Filter

## What is the Frangi Filter?

The Frangi filter is a **vesselness filter** that detects tube-like (vessel-like) structures in images.

**How it works:**
1. Computes Hessian matrix (2nd derivatives) at each pixel
2. Analyzes eigenvalues (λ1, λ2) of the Hessian
3. For vessels:
   - λ1 ≈ 0 (perpendicular to vessel)
   - λ2 >> 0 (along vessel axis)
   - Ratio reveals "tubularity"
4. Outputs "vesselness score" (0-1) for each pixel

**Key insight:** Vessels have elongated, tube-like structure → high Hessian ratio

---

## Installation

```bash
pip install scikit-image opencv-python numpy scipy
```

---

## Step 1: Apply Frangi Filter

```python
import cv2
import numpy as np
from skimage.filters import frangi, hessian
from skimage import io, color
import matplotlib.pyplot as plt

# Load fundus image
img = cv2.imread('retinal_image.jpg')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# CLAHE preprocessing (improves vessel contrast)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
enhanced = clahe.apply(gray)

# Apply Frangi filter
# sigmas: range of vessel widths to detect (1-10 = vessels 1-10 pixels wide)
frangi_output = frangi(enhanced, sigmas=range(1, 10))

print(f"Frangi output shape: {frangi_output.shape}")
print(f"Frangi value range: {frangi_output.min():.4f} - {frangi_output.max():.4f}")
```

**What you get:**
- Array of same shape as input image
- Each pixel contains vesselness score (0-1)
- High values = likely vessel pixels
- Low values = non-vessel (background)

---

## Step 2: Binarize Frangi Output

Convert continuous vesselness scores to binary mask:

```python
# Method 1: Simple threshold
threshold = np.percentile(frangi_output, 95)  # Top 5% as vessels
vessel_binary = (frangi_output > threshold).astype(np.uint8) * 255

# Method 2: Otsu's method (automatic threshold)
_, vessel_binary = cv2.threshold(
    (frangi_output * 255).astype(np.uint8),
    0, 255,
    cv2.THRESH_BINARY + cv2.THRESH_OTSU
)

# Method 3: Multi-level thresholding
low_threshold = np.percentile(frangi_output, 80)
mid_threshold = np.percentile(frangi_output, 90)
high_threshold = np.percentile(frangi_output, 95)

vessel_weak = (frangi_output > low_threshold).astype(np.uint8)
vessel_strong = (frangi_output > mid_threshold).astype(np.uint8)
```

---

## Step 3: Extract Core Features

### 3.1 Vessel Area & Density

```python
def extract_area_features(binary_mask: np.ndarray) -> dict:
    """Extract area-based features"""
    
    h, w = binary_mask.shape
    total_pixels = h * w
    
    # Vessel pixels (assuming binary_mask is 0-255)
    vessel_pixels = np.sum(binary_mask > 128)
    
    # Metrics
    vessel_area = vessel_pixels  # in pixels²
    vessel_density = vessel_pixels / total_pixels  # 0-1
    
    return {
        'vessel_area_pixels': vessel_area,
        'vessel_density': vessel_density,
        'image_coverage_percent': vessel_density * 100,
        'non_vessel_pixels': total_pixels - vessel_pixels
    }

# Usage
area_features = extract_area_features(vessel_binary)
print(f"Vessel density: {area_features['vessel_density']:.4f}")
print(f"Image coverage: {area_features['image_coverage_percent']:.2f}%")
```

### 3.2 Connected Components (Vessel Count)

```python
def extract_connected_vessels(binary_mask: np.ndarray) -> dict:
    """Count individual vessels and their properties"""
    
    # Label connected components
    num_labels, labeled_array = cv2.connectedComponents(binary_mask)
    
    # Remove background (label 0)
    vessel_labels = num_labels - 1
    
    # Get size of each vessel
    vessel_sizes = {}
    for label in range(1, num_labels):
        size = np.sum(labeled_array == label)
        vessel_sizes[label] = size
    
    # Filter out noise (very small blobs)
    min_vessel_size = 10  # pixels
    valid_vessels = {k: v for k, v in vessel_sizes.items() if v > min_vessel_size}
    
    return {
        'total_vessel_count': len(valid_vessels),
        'vessel_sizes': valid_vessels,
        'mean_vessel_size': np.mean(list(valid_vessels.values())) if valid_vessels else 0,
        'std_vessel_size': np.std(list(valid_vessels.values())) if valid_vessels else 0,
        'max_vessel_size': max(valid_vessels.values()) if valid_vessels else 0,
        'min_vessel_size': min(valid_vessels.values()) if valid_vessels else 0,
    }

# Usage
vessel_stats = extract_connected_vessels(vessel_binary)
print(f"Vessel count: {vessel_stats['total_vessel_count']}")
print(f"Mean vessel size: {vessel_stats['mean_vessel_size']:.1f} pixels")
```

### 3.3 Vessel Caliber (Width)

```python
def extract_vessel_caliber(binary_mask: np.ndarray, 
                           labeled_array: np.ndarray) -> dict:
    """
    Estimate vessel width using morphological operations
    Assumes vessel_binary is already connected-component labeled
    """
    
    # Method 1: Skeleton-based (thinning)
    # Reduce vessels to 1-pixel-wide centerlines
    from skimage.morphology import skeletonize
    
    skeleton = skeletonize((binary_mask > 128).astype(np.uint8))
    skeleton_pixels = np.sum(skeleton)
    
    # Estimate width: vessel_area / skeleton_length
    mean_width = np.sum(binary_mask > 128) / (skeleton_pixels + 1e-6)
    
    # Method 2: Distance transform
    from scipy.ndimage import distance_transform_edt
    
    distance_map = distance_transform_edt(binary_mask > 128)
    
    # Max distance in each direction ≈ radius
    max_distance = np.max(distance_map)
    diameter = max_distance * 2
    
    # Percentile widths
    percentile_widths = {
        'p50': np.percentile(distance_map[distance_map > 0], 50) * 2,
        'p75': np.percentile(distance_map[distance_map > 0], 75) * 2,
        'p90': np.percentile(distance_map[distance_map > 0], 90) * 2,
        'p95': np.percentile(distance_map[distance_map > 0], 95) * 2,
        'max': np.max(distance_map) * 2
    }
    
    return {
        'mean_vessel_width_pixels': mean_width,
        'max_vessel_diameter': diameter,
        'width_percentiles': percentile_widths,
        'skeleton_length': skeleton_pixels,
        'width_regularity': 1 - (np.std(distance_map[distance_map > 0]) / 
                                  np.mean(distance_map[distance_map > 0]))
    }

# Usage
caliber_features = extract_vessel_caliber(vessel_binary, labeled_array)
print(f"Mean vessel width: {caliber_features['mean_vessel_width_pixels']:.2f} pixels")
print(f"Width regularity: {caliber_features['width_regularity']:.2f}")
```

### 3.4 Arteriolar-to-Venular Ratio (AVR)

```python
def extract_avr(binary_mask: np.ndarray, 
                color_img: np.ndarray = None) -> dict:
    """
    Estimate Arteriolar-to-Venular Ratio
    
    In color images:
    - Arterioles: brighter red (R >> B)
    - Venules: darker red (R ≈ B)
    """
    
    if color_img is None:
        # Without color info, estimate based on vessel size distribution
        # (Arteries typically wider but fewer; veins narrower but more numerous)
        
        num_labels, labeled_array = cv2.connectedComponents(binary_mask)
        vessel_sizes = [np.sum(labeled_array == label) for label in range(1, num_labels)]
        
        # Approximate: large vessels = arteries, small = veins
        large_vessel_threshold = np.percentile(vessel_sizes, 75)
        
        arteries = np.sum(np.array(vessel_sizes) > large_vessel_threshold)
        veins = np.sum(np.array(vessel_sizes) <= large_vessel_threshold)
        
        avr = (arteries / (veins + 1e-6)) if veins > 0 else 0
        
        return {
            'estimated_arteries': arteries,
            'estimated_veins': veins,
            'avr': avr,
            'method': 'size-based approximation'
        }
    
    else:
        # With color: analyze red/blue ratio in vessel pixels
        # Red channel high, Blue channel low = artery
        # Red ≈ Blue = vein
        
        hsv = cv2.cvtColor(color_img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        
        # Red hue: 0-10 or 170-180 in HSV
        red_mask = ((h < 10) | (h > 170)).astype(np.uint8) * (binary_mask > 128)
        
        # Blue hue: 100-130 in HSV
        blue_mask = ((h > 100) & (h < 130)).astype(np.uint8) * (binary_mask > 128)
        
        red_vessels = np.sum(red_mask)
        blue_vessels = np.sum(blue_mask)
        
        avr = (red_vessels / (blue_vessels + 1e-6)) if blue_vessels > 0 else 0
        
        return {
            'red_vessels': red_vessels,
            'blue_vessels': blue_vessels,
            'avr': avr,
            'method': 'color-based (HSV hue)',
            'interpretation': 'AVR normal ≈ 0.8-1.0; <0.7 indicates vascular narrowing'
        }

# Usage (without color)
avr_features = extract_avr(vessel_binary)
print(f"AVR: {avr_features['avr']:.3f}")
```

### 3.5 Vessel Tortuosity

```python
def extract_tortuosity(binary_mask: np.ndarray, 
                       labeled_array: np.ndarray) -> dict:
    """
    Measure vessel curvature/tortuosity
    Straight vessels: tortuosity ≈ 1
    Curved vessels: tortuosity >> 1
    """
    
    from skimage.morphology import skeletonize
    
    tortuosity_scores = []
    
    # For each vessel (connected component)
    for label in np.unique(labeled_array)[1:]:  # Skip background (0)
        vessel_mask = (labeled_array == label).astype(np.uint8)
        
        if np.sum(vessel_mask) < 5:  # Skip tiny fragments
            continue
        
        # Get skeleton
        skeleton = skeletonize(vessel_mask)
        skeleton_points = np.argwhere(skeleton > 0)
        
        if len(skeleton_points) < 3:
            continue
        
        # Path length (actual skeleton length)
        path_length = len(skeleton_points)
        
        # Euclidean distance from start to end
        start = skeleton_points[0]
        end = skeleton_points[-1]
        euclidean_distance = np.sqrt((start[0]-end[0])**2 + (start[1]-end[1])**2)
        
        # Tortuosity = path_length / euclidean_distance
        # 1.0 = straight line
        # >1.5 = significantly curved
        tortuosity = path_length / (euclidean_distance + 1e-6)
        tortuosity_scores.append(tortuosity)
    
    return {
        'mean_tortuosity': np.mean(tortuosity_scores) if tortuosity_scores else 0,
        'std_tortuosity': np.std(tortuosity_scores) if tortuosity_scores else 0,
        'max_tortuosity': np.max(tortuosity_scores) if tortuosity_scores else 0,
        'vessels_analyzed': len(tortuosity_scores),
        'interpretation': 'Normal <1.1; Tortuous >1.3 (sign of vascular stress)'
    }

# Usage
tortuosity_features = extract_tortuosity(vessel_binary, labeled_array)
print(f"Mean tortuosity: {tortuosity_features['mean_tortuosity']:.3f}")
```

### 3.6 Fractal Dimension

```python
def extract_fractal_dimension(binary_mask: np.ndarray) -> dict:
    """
    Compute fractal dimension of vessel network
    Measures complexity/branching pattern
    
    FD = 2.0: space-filling branching
    FD = 1.0: simple linear structure
    FD = 1.5: typical retinal vessel network
    """
    
    from scipy.ndimage import binary_dilation
    
    # Box counting method
    def box_count(binary_image, max_box_size=None):
        """Count boxes needed to cover all vessel pixels"""
        
        if max_box_size is None:
            max_box_size = min(binary_image.shape) // 2
        
        counts = []
        sizes = []
        
        for box_size in range(1, max_box_size):
            # Resize to grid
            n_boxes_h = binary_image.shape[0] // box_size
            n_boxes_w = binary_image.shape[1] // box_size
            
            if n_boxes_h == 0 or n_boxes_w == 0:
                continue
            
            # Count non-empty boxes
            count = 0
            for i in range(n_boxes_h):
                for j in range(n_boxes_w):
                    box = binary_image[
                        i*box_size:(i+1)*box_size,
                        j*box_size:(j+1)*box_size
                    ]
                    if np.sum(box) > 0:
                        count += 1
            
            counts.append(count)
            sizes.append(box_size)
        
        return np.array(sizes), np.array(counts)
    
    sizes, counts = box_count(binary_mask > 128)
    
    # Log-log fit
    log_sizes = np.log(sizes)
    log_counts = np.log(counts)
    
    # Fractal dimension ≈ -slope of log-log plot
    coeffs = np.polyfit(log_sizes, log_counts, 1)
    fractal_dimension = -coeffs[0]
    
    return {
        'fractal_dimension': fractal_dimension,
        'interpretation': f"FD {fractal_dimension:.2f}: " + (
            "Normal branching" if 1.4 < fractal_dimension < 1.6 else
            "Abnormal (too simple/complex)"
        )
    }

# Usage
fd_features = extract_fractal_dimension(vessel_binary)
print(f"Fractal dimension: {fd_features['fractal_dimension']:.3f}")
```

---

## Step 4: Extract from Frangi Intensity Map

Features from the *continuous* Frangi output (not just binary mask):

```python
def extract_frangi_intensity_features(frangi_output: np.ndarray) -> dict:
    """
    Extract features from actual Frangi vesselness scores
    (Before binarization)
    """
    
    # Threshold for vessel pixels
    threshold = np.percentile(frangi_output, 90)
    vessel_pixels = frangi_output[frangi_output > threshold]
    
    return {
        'mean_vesselness': np.mean(vessel_pixels),
        'std_vesselness': np.std(vessel_pixels),
        'max_vesselness': np.max(frangi_output),
        'min_vesselness': np.min(frangi_output),
        
        # Percentiles
        'p25_vesselness': np.percentile(frangi_output, 25),
        'p50_vesselness': np.percentile(frangi_output, 50),
        'p75_vesselness': np.percentile(frangi_output, 75),
        'p90_vesselness': np.percentile(frangi_output, 90),
        
        # Distribution shape
        'vesselness_skewness': 3 * (np.mean(vessel_pixels) - np.median(vessel_pixels)) / np.std(vessel_pixels),
        'vesselness_entropy': -np.sum((vessel_pixels / np.sum(vessel_pixels)) * np.log2(vessel_pixels / np.sum(vessel_pixels) + 1e-10))
    }

# Usage
frangi_features = extract_frangi_intensity_features(frangi_output)
print(f"Mean vesselness: {frangi_features['mean_vesselness']:.4f}")
```

---

## Step 5: Complete Pipeline

```python
def complete_frangi_analysis(image_path: str) -> dict:
    """Full pipeline: load image → Frangi → extract all features"""
    
    # Load and preprocess
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    
    # Apply Frangi
    frangi_output = frangi(enhanced, sigmas=range(1, 10))
    
    # Binarize
    threshold = np.percentile(frangi_output, 95)
    vessel_binary = (frangi_output > threshold).astype(np.uint8) * 255
    
    # Connect components
    num_labels, labeled_array = cv2.connectedComponents(vessel_binary)
    
    # Extract all feature groups
    all_features = {
        'frangi_intensity': extract_frangi_intensity_features(frangi_output),
        'area': extract_area_features(vessel_binary),
        'connectivity': extract_connected_vessels(vessel_binary),
        'caliber': extract_vessel_caliber(vessel_binary, labeled_array),
        'tortuosity': extract_tortuosity(vessel_binary, labeled_array),
        'fractal': extract_fractal_dimension(vessel_binary),
    }
    
    # Add AVR (requires color image)
    all_features['avr'] = extract_avr(vessel_binary, img)
    
    return all_features

# Usage
features = complete_frangi_analysis('retinal_image.jpg')

# Print results
import json
print(json.dumps(features, indent=2, default=str))
```

---

## Feature Summary Table

| Feature | Range | Meaning | Normal (Healthy) | Abnormal (Diseased) |
|---------|-------|---------|------------------|-------------------|
| Vessel Density | 0-1 | % image coverage | 0.15-0.25 | <0.10 or >0.30 |
| Vessel Count | ≥0 | # separate vessels | 200-400 | <100 or >500 |
| Mean Width | Pixels | Average diameter | 12-18 px | <8 px or >25 px |
| AVR | 0.5-1.5 | Artery:Vein ratio | 0.8-1.0 | <0.7 (narrowing) |
| Tortuosity | 1.0-2.0 | Curvature | 1.0-1.1 | >1.3 (tortuous) |
| Fractal Dim | 1-2 | Network complexity | 1.4-1.6 | <1.3 or >1.7 |
| Frangi Score | 0-1 | Vesselness | High (>0.05) | Low (<0.02) |

---

## Visualization

```python
import matplotlib.pyplot as plt

def visualize_frangi_extraction(image_path: str):
    """Visualize Frangi filter results step-by-step"""
    
    # Load
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Preprocess
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    
    # Frangi
    frangi_output = frangi(enhanced, sigmas=range(1, 10))
    
    # Binary
    threshold = np.percentile(frangi_output, 95)
    vessel_binary = (frangi_output > threshold).astype(np.uint8) * 255
    
    # Distance map
    from scipy.ndimage import distance_transform_edt
    distance_map = distance_transform_edt(vessel_binary > 128)
    
    # Plot
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    axes[0, 0].imshow(gray, cmap='gray')
    axes[0, 0].set_title('Original (Grayscale)')
    
    axes[0, 1].imshow(enhanced, cmap='gray')
    axes[0, 1].set_title('CLAHE Enhanced')
    
    axes[0, 2].imshow(frangi_output, cmap='hot')
    axes[0, 2].set_title('Frangi Vesselness Score')
    axes[0, 2].colorbar = plt.colorbar(axes[0, 2].images[0], ax=axes[0, 2])
    
    axes[1, 0].imshow(vessel_binary, cmap='gray')
    axes[1, 0].set_title('Binarized Vessels')
    
    axes[1, 1].imshow(distance_map, cmap='viridis')
    axes[1, 1].set_title('Distance Map (Caliber)')
    
    # Skeleton
    from skimage.morphology import skeletonize
    skeleton = skeletonize((vessel_binary > 128).astype(np.uint8))
    axes[1, 2].imshow(skeleton, cmap='gray')
    axes[1, 2].set_title('Vessel Skeleton')
    
    plt.tight_layout()
    plt.savefig('frangi_analysis.png', dpi=150)
    plt.show()

# Usage
visualize_frangi_extraction('retinal_image.jpg')
```

---

## Key Takeaways

1. **Frangi output is continuous** (0-1), not binary
2. **Threshold carefully** — percentile-based is more robust than fixed
3. **Extract multiple features** — single metric insufficient
4. **Caliber requires post-processing** — skeleton or distance transform
5. **Validation matters** — compare against manual annotations if possible
6. **Features vary by image quality** — preprocess with CLAHE first

---

## Common Pitfalls

❌ **Don't:** Use fixed threshold (e.g., >0.5) across all images
✅ **Do:** Use percentile (e.g., >95th) for consistency

❌ **Don't:** Skip connected-component filtering (noise removal)
✅ **Do:** Remove vessels <10 pixels (noise)

❌ **Don't:** Estimate vessel width directly from Frangi
✅ **Do:** Binarize first, then use skeleton or distance transform

❌ **Don't:** Use raw pixel counts without normalization
✅ **Do:** Normalize by image size for cross-image comparison
