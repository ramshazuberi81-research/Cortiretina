# Extracting Diabetic Retinopathy Lesions & Vascular Data from Kaggle

## Overview of Available Data

The customized Kaggle EyePACS dataset includes **pixel-level annotations** for:
- **Ocular Lesions**: Microaneurysms (MA), Hemorrhages (H), Cotton Wool Spots (CWS), Venous Beating (VB), Neovascularization (NV), Exudates (EX)
- **Image-Level Labels**: DR Grade (0-4), Referable Status, DME Severity (0-3)
- **Vascular Metrics**: Vessel caliber, arteriolar-to-venular ratio (AVR)

---

## Step 1: Access Kaggle Datasets

### Prerequisites
1. **Create Kaggle Account** (free at kaggle.com)
2. **Install Kaggle CLI**
```bash
pip install kaggle
```

3. **Set Up API Credentials**
   - Go to: kaggle.com → Settings → API
   - Click "Create New API Token" (downloads `kaggle.json`)
   - Move to home directory:
   ```bash
   mkdir ~/.kaggle
   cp kaggle.json ~/.kaggle/
   chmod 600 ~/.kaggle/kaggle.json
   ```

---

## Step 2: Download the Datasets

### Option A: Direct Kaggle CLI Download
```bash
# Kaggle EyePACS (88,702 images)
kaggle datasets download -d eyepacs/diabetic-retinopathy-detection

# Messidor-2 (1,748 images)
kaggle datasets download -d eyepacs/messidor-2

# Retinal Vessel Segmentation
kaggle datasets download -d ayush02102001/retinal-vessel-segmentation-dataset

# Lesion Annotations (if available)
kaggle datasets download -d ratthachat/aptos2019-blindness-detection
```

### Option B: Direct Download via Browser
1. Visit: `kaggle.com/datasets/eyepacs/diabetic-retinopathy-detection`
2. Click "Download" button
3. Extract to working directory

---

## Step 3: Data Structure & Extraction

### Directory Structure
```
diabetic-retinopathy-detection/
├── trainLabels.csv          # DR grades (0-4)
├── retinopathy_solution.csv # Severity labels
├── train/                   # ~35,000 training images
│   ├── 10000_left.jpeg
│   ├── 10000_right.jpeg
│   └── ...
└── test/                    # ~53,000 test images
    └── ...

messidor-2/
├── messidor_data.csv        # DR grades + lesion locations
└── Base12/                  # 1,748 fundus images
    └── ...
```

---

## Step 4: Python Code to Extract & Process Data

### 4.1 Load Basic Dataset Structure
```python
import pandas as pd
import numpy as np
from PIL import Image
import os
import glob

# Load training labels
train_labels = pd.read_csv('diabetic-retinopathy-detection/trainLabels.csv')
print(train_labels.head())

# Output:
# image              level
# 10002_left         0      (Normal)
# 10005_right        4      (Proliferative DR)
# ...

# Distribution of DR grades
print(train_labels['level'].value_counts().sort_index())
```

### 4.2 Extract Lesion Coordinates (If Available)
```python
# For datasets with pixel-level annotations (e.g., IDRiD)
# The lesion data is typically in a separate annotation file

lesion_data = pd.read_csv('idrid_dataset/lesions.csv')
# Columns: image_id, lesion_type, x_coordinate, y_coordinate, area_pixels

# Filter by lesion type
microaneurysms = lesion_data[lesion_data['lesion_type'] == 'microaneurysm']
hemorrhages = lesion_data[lesion_data['lesion_type'] == 'hemorrhage']
exudates = lesion_data[lesion_data['lesion_type'] == 'exudate']

print(f"Total microaneurysms: {len(microaneurysms)}")
print(f"Total hemorrhages: {len(hemorrhages)}")
```

### 4.3 Extract Vascular Metrics from Images
```python
import cv2
from skimage import segmentation, morphology

def extract_vessel_features(image_path):
    """Extract vascular caliber and vessel characteristics"""
    
    # Load fundus image
    img = cv2.imread(image_path)
    if img is None:
        return None
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    
    # Vessel segmentation using Frangi filter (enhanced contrast)
    from skimage.filters import frangi, hessian
    
    # Apply Frangi filter to detect vessel-like structures
    vessel_mask = frangi(enhanced, sigmas=range(1, 10), alpha=0.5, beta=0.5)
    
    # Binarize
    _, vessel_binary = cv2.threshold(vessel_mask.astype(np.uint8) * 255, 
                                     30, 255, cv2.THRESH_BINARY)
    
    # Extract metrics
    vessel_area = np.sum(vessel_binary) / 255  # pixels
    vessel_density = vessel_area / (gray.shape[0] * gray.shape[1])
    
    # Arteriolar-to-Venular Ratio (simplified - would need color info for full calculation)
    contours, _ = cv2.findContours(vessel_binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    vessel_count = len(contours)
    
    return {
        'vessel_area': vessel_area,
        'vessel_density': vessel_density,
        'vessel_count': vessel_count,
        'mean_vessel_width': vessel_area / max(vessel_count, 1)
    }

# Process all training images
results = []
image_dir = 'diabetic-retinopathy-detection/train/'

for idx, row in train_labels.head(100).iterrows():  # First 100 for testing
    image_path = f"{image_dir}{row['image']}.jpeg"
    
    if os.path.exists(image_path):
        features = extract_vessel_features(image_path)
        if features:
            features['image_id'] = row['image']
            features['dr_grade'] = row['level']
            results.append(features)

# Create features dataframe
features_df = pd.DataFrame(results)
print(features_df.head())
```

### 4.4 Correlate Vascular Features with DR Grade
```python
import matplotlib.pyplot as plt

# Group by DR grade
fig, axes = plt.subplots(2, 2, figsize=(12, 10))

axes[0, 0].boxplot([features_df[features_df['dr_grade'] == i]['vessel_density'].values 
                      for i in range(5)])
axes[0, 0].set_title('Vessel Density by DR Grade')
axes[0, 0].set_xlabel('DR Grade (0=Normal, 4=Proliferative)')

axes[0, 1].boxplot([features_df[features_df['dr_grade'] == i]['mean_vessel_width'].values 
                      for i in range(5)])
axes[0, 1].set_title('Mean Vessel Width by DR Grade')

axes[1, 0].scatter(features_df['vessel_density'], features_df['dr_grade'], alpha=0.6)
axes[1, 0].set_title('Vessel Density vs DR Grade')
axes[1, 0].set_xlabel('Vessel Density')
axes[1, 0].set_ylabel('DR Grade')

plt.tight_layout()
plt.savefig('vessel_features_by_dr_grade.png')
plt.show()

# Statistical correlation
print(features_df[['vessel_density', 'vessel_count', 'mean_vessel_width', 'dr_grade']].corr())
```

---

## Step 5: Extract Messidor-2 Data

### 5.1 Load Messidor-2 Dataset
```python
# Messidor-2 structure
messidor_labels = pd.read_csv('messidor-2/messidor_data.csv')
# Columns: filename, DR_grade, lesions_present, etc.

messidor_dir = 'messidor-2/Base12/'
messidor_images = glob.glob(f'{messidor_dir}/*.jpg')

print(f"Total Messidor-2 images: {len(messidor_images)}")
print(messidor_labels.head())

# DR grade distribution in Messidor-2
print(messidor_labels['DR_grade'].value_counts())
```

### 5.2 Extract Both Datasets into Combined DataFrame
```python
def create_combined_dataset(eyepacs_dir, messidor_dir):
    """Combine EyePACS and Messidor-2 with extracted features"""
    
    combined_data = []
    
    # Process EyePACS
    eyepacs_labels = pd.read_csv(f'{eyepacs_dir}/trainLabels.csv')
    for idx, row in eyepacs_labels.iterrows():
        image_path = f"{eyepacs_dir}/train/{row['image']}.jpeg"
        if os.path.exists(image_path):
            features = extract_vessel_features(image_path)
            if features:
                combined_data.append({
                    'dataset': 'EyePACS',
                    'image_id': row['image'],
                    'dr_grade': row['level'],
                    **features
                })
    
    # Process Messidor-2
    messidor_labels = pd.read_csv(f'{messidor_dir}/messidor_data.csv')
    for idx, row in messidor_labels.iterrows():
        image_path = f"{messidor_dir}/Base12/{row['filename']}"
        if os.path.exists(image_path):
            features = extract_vessel_features(image_path)
            if features:
                combined_data.append({
                    'dataset': 'Messidor-2',
                    'image_id': row['filename'],
                    'dr_grade': row['DR_grade'],
                    **features
                })
    
    return pd.DataFrame(combined_data)

# Create combined dataset
combined_df = create_combined_dataset('diabetic-retinopathy-detection', 'messidor-2')
combined_df.to_csv('combined_retinal_features.csv', index=False)

print(f"Combined dataset shape: {combined_df.shape}")
print(combined_df.head())
```

---

## Step 6: Structure for Your Vessel Calibration Agent

### 6.1 Prepare Data for Agent Training
```python
# Create normalized feature set for agents
from sklearn.preprocessing import StandardScaler
from sklearn.train_test_split import train_test_split

# Select vascular features
feature_cols = ['vessel_area', 'vessel_density', 'vessel_count', 'mean_vessel_width']
X = combined_df[feature_cols].fillna(0)
y = combined_df['dr_grade']

# Normalize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split for training agents
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# Save for agent use
np.save('vessel_features_train.npy', X_train)
np.save('dr_labels_train.npy', y_train)
np.save('vessel_features_test.npy', X_test)
np.save('dr_labels_test.npy', y_test)

print(f"Training set: {X_train.shape}")
print(f"Test set: {X_test.shape}")
```

### 6.2 Create Agent-Ready Data Dictionary
```python
# Create structured data for agents
agent_data = {
    'metadata': {
        'total_images': len(combined_df),
        'datasets': ['EyePACS', 'Messidor-2'],
        'feature_names': feature_cols,
        'dr_grades': {0: 'Normal', 1: 'Mild', 2: 'Moderate', 3: 'Severe', 4: 'Proliferative'}
    },
    'features': {
        'train': X_train.tolist(),
        'test': X_test.tolist()
    },
    'labels': {
        'train': y_train.tolist(),
        'test': y_test.tolist()
    },
    'raw_data': combined_df.to_dict(orient='records')
}

import json
with open('agent_vessel_data.json', 'w') as f:
    json.dump(agent_data, f)
```

---

## Step 7: Advanced - Extract Lesion Density Maps

### For IDRiD Dataset (Pixel-Level Annotations)
```python
def create_lesion_heatmap(image_path, annotations_df, lesion_type):
    """Create heatmap of specific lesion distribution"""
    
    img = cv2.imread(image_path)
    h, w = img.shape[:2]
    
    # Create blank heatmap
    heatmap = np.zeros((h, w), dtype=np.float32)
    
    # Get lesion coordinates for this image
    lesion_coords = annotations_df[annotations_df['lesion_type'] == lesion_type]
    
    # Draw Gaussian blobs at lesion centers
    for _, lesion in lesion_coords.iterrows():
        x, y = int(lesion['x_coordinate']), int(lesion['y_coordinate'])
        cv2.circle(heatmap, (x, y), radius=20, color=1, thickness=-1)
    
    # Gaussian blur for smooth distribution
    heatmap = cv2.GaussianBlur(heatmap, (51, 51), 0)
    
    return heatmap

# Example: Create microaneurysm heatmap
# microaneurysm_heatmap = create_lesion_heatmap('image.jpg', lesion_data, 'microaneurysm')
```

---

## Quick Start Command Summary

```bash
# 1. Install dependencies
pip install kaggle pandas numpy opencv-python scikit-image scikit-learn matplotlib

# 2. Authenticate
kaggle config set -n path -v ~/.kaggle

# 3. Download datasets
kaggle datasets download -d eyepacs/diabetic-retinopathy-detection
unzip diabetic-retinopathy-detection.zip

# 4. Run Python extraction
python extract_retinal_features.py

# 5. Output files created:
# - combined_retinal_features.csv
# - agent_vessel_data.json
# - vessel_features_train.npy
# - vessel_features_test.npy
```

---

## Key Extraction Points for Your Agents

| Feature | Source | Use in Agent |
|---------|--------|-------------|
| Vessel Density | Frangi filter segmentation | Baseline calibration |
| Mean Vessel Width | Contour analysis | Distensibility proxy |
| Vessel Count | Contour detection | NO-dependent response |
| DR Grade | Label file | Outcome correlation |
| Lesion Distribution | Pixel-level annotations | Risk stratification |
| Image Quality | Contrast metrics | Data preprocessing agent |

---

## Troubleshooting

**Issue**: "No module named kaggle"
```bash
pip install --upgrade kaggle
```

**Issue**: "403 Forbidden" when downloading
- Re-authenticate: `kaggle config set -n path -v ~/.kaggle`
- Check API token expiration on kaggle.com

**Issue**: Large file sizes (~10GB+)
- Download in batches using `--unzip` flag
- Use `--force` to skip existing files

**Issue**: Memory errors processing all images
```python
# Process in chunks
for batch_start in range(0, len(train_labels), 1000):
    batch = train_labels.iloc[batch_start:batch_start+1000]
    # process batch
```
